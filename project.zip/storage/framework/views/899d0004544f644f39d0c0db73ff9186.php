

<?php $__env->startSection('content'); ?>
<div class="min-h-screen flex items-center justify-center bg-gray-100 py-12 px-4 sm:px-6 lg:px-8">
    <div class="max-w-md w-full bg-white shadow-lg rounded-lg p-8">
        <h2 class="text-2xl font-bold text-center text-gray-800 mb-6">ثبت نوم</h2>

        <?php if($errors->any()): ?>
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p><?php echo e($error); ?></p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('register')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="mb-4">
                <label class="block text-gray-700 font-medium mb-2">نوم</label>
                <input type="text" name="name" value="<?php echo e(old('name')); ?>" class="w-full border border-gray-300 rounded-md px-4 py-2" required autofocus>
            </div>
            <div class="mb-4">
                <label class="block text-gray-700 font-medium mb-2">ایمیل</label>
                <input type="email" name="email" value="<?php echo e(old('email')); ?>" class="w-full border border-gray-300 rounded-md px-4 py-2" required>
            </div>
            <div class="mb-4">
                <label class="block text-gray-700 font-medium mb-2">پاسورډ</label>
                <input type="password" name="password" class="w-full border border-gray-300 rounded-md px-4 py-2" required>
            </div>
            <div class="mb-6">
                <label class="block text-gray-700 font-medium mb-2">پاسورډ تایید</label>
                <input type="password" name="password_confirmation" class="w-full border border-gray-300 rounded-md px-4 py-2" required>
            </div>
            <button type="submit" class="w-full bg-green-600 text-white py-2 rounded-md hover:bg-green-700 transition">ثبت نوم</button>
        </form>
        <p class="text-center text-gray-600 mt-4">
            حساب لرئ؟ <a href="<?php echo e(route('login')); ?>" class="text-blue-600 hover:underline">ننوتل</a>
        </p>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Web For TA\gawhar-amu-travel\resources\views/auth/register.blade.php ENDPATH**/ ?>