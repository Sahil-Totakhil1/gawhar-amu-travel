

<?php $__env->startSection('content'); ?>
<div class="max-w-4xl mx-auto">
    <h1 class="text-3xl font-bold mb-8 dark:text-white text-gray-800"><?php echo app('translator')->get('messages.edit_ad_title'); ?></h1>

    <?php if($errors->any()): ?>
        <div class="bg-red-100 dark:bg-red-800 border border-red-400 dark:border-red-600 text-red-700 dark:text-red-200 px-4 py-3 rounded mb-6">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('admin.ads.update', $ad)); ?>" method="POST" enctype="multipart/form-data" class="bg-white dark:bg-gray-800 shadow-md rounded-lg p-8">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <!-- په دریو ژبو کې سرلیک -->
        <div class="mb-6">
            <label class="block text-gray-700 dark:text-gray-300 font-bold mb-2"><?php echo app('translator')->get('messages.title_ps'); ?> *</label>
            <input type="text" name="title_ps" value="<?php echo e(old('title_ps', $ad->title['ps'] ?? '')); ?>" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2" required>
        </div>
        <div class="mb-6">
            <label class="block text-gray-700 dark:text-gray-300 font-bold mb-2"><?php echo app('translator')->get('messages.title_dr'); ?></label>
            <input type="text" name="title_dr" value="<?php echo e(old('title_dr', $ad->title['dr'] ?? '')); ?>" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2">
        </div>
        <div class="mb-6">
            <label class="block text-gray-700 dark:text-gray-300 font-bold mb-2"><?php echo app('translator')->get('messages.title_en'); ?></label>
            <input type="text" name="title_en" value="<?php echo e(old('title_en', $ad->title['en'] ?? '')); ?>" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2">
        </div>

        <!-- په دریو ژبو کې تشریح -->
        <div class="mb-6">
            <label class="block text-gray-700 dark:text-gray-300 font-bold mb-2"><?php echo app('translator')->get('messages.description_ps'); ?></label>
            <textarea name="description_ps" rows="3" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2"><?php echo e(old('description_ps', $ad->description['ps'] ?? '')); ?></textarea>
        </div>
        <div class="mb-6">
            <label class="block text-gray-700 dark:text-gray-300 font-bold mb-2"><?php echo app('translator')->get('messages.description_dr'); ?></label>
            <textarea name="description_dr" rows="3" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2"><?php echo e(old('description_dr', $ad->description['dr'] ?? '')); ?></textarea>
        </div>
        <div class="mb-6">
            <label class="block text-gray-700 dark:text-gray-300 font-bold mb-2"><?php echo app('translator')->get('messages.description_en'); ?></label>
            <textarea name="description_en" rows="3" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2"><?php echo e(old('description_en', $ad->description['en'] ?? '')); ?></textarea>
        </div>

        <!-- کټګوري -->
        <div class="mb-6">
            <label class="block text-gray-700 dark:text-gray-300 font-bold mb-2"><?php echo app('translator')->get('messages.category'); ?> *</label>
            <select name="category" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2" required>
                <option value=""><?php echo app('translator')->get('messages.select_option'); ?></option>
                <option value="visa" <?php echo e(old('category', $ad->category) == 'visa' ? 'selected' : ''); ?>><?php echo app('translator')->get('messages.visa'); ?></option>
                <option value="tour" <?php echo e(old('category', $ad->category) == 'tour' ? 'selected' : ''); ?>><?php echo app('translator')->get('messages.tour'); ?></option>
                <option value="hajj" <?php echo e(old('category', $ad->category) == 'hajj' ? 'selected' : ''); ?>><?php echo app('translator')->get('messages.hajj'); ?></option>
                <option value="ticket" <?php echo e(old('category', $ad->category) == 'ticket' ? 'selected' : ''); ?>><?php echo app('translator')->get('messages.ticket'); ?></option>
                <option value="residence" <?php echo e(old('category', $ad->category) == 'residence' ? 'selected' : ''); ?>><?php echo app('translator')->get('messages.residence'); ?></option>
                <option value="other" <?php echo e(old('category', $ad->category) == 'other' ? 'selected' : ''); ?>><?php echo app('translator')->get('messages.other'); ?></option>
            </select>
        </div>

        <!-- قیمت -->
        <div class="mb-6">
            <label class="block text-gray-700 dark:text-gray-300 font-bold mb-2"><?php echo app('translator')->get('messages.price_dollar'); ?></label>
            <input type="number" step="0.01" name="price" value="<?php echo e(old('price', $ad->price)); ?>" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2">
        </div>

        <!-- موقعیت -->
        <div class="mb-6">
            <label class="block text-gray-700 dark:text-gray-300 font-bold mb-2"><?php echo app('translator')->get('messages.location'); ?></label>
            <input type="text" name="location" value="<?php echo e(old('location', $ad->location)); ?>" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2">
        </div>

        <!-- اوسنی انځور -->
        <?php if($ad->image): ?>
        <div class="mb-6">
            <label class="block text-gray-700 dark:text-gray-300 font-bold mb-2"><?php echo app('translator')->get('messages.current_image'); ?></label>
            <img src="<?php echo e(asset('storage/' . $ad->image)); ?>" class="h-20 w-20 object-cover rounded border dark:border-gray-600">
        </div>
        <?php endif; ?>

        <!-- نوی انځور -->
        <div class="mb-6">
            <label class="block text-gray-700 dark:text-gray-300 font-bold mb-2"><?php echo app('translator')->get('messages.new_image_optional'); ?></label>
            <input type="file" name="image" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2">
        </div>

        <!-- ویډیو لینک -->
        <div class="mb-6">
            <label class="block text-gray-700 dark:text-gray-300 font-bold mb-2"><?php echo app('translator')->get('messages.video_url'); ?></label>
            <input type="url" name="video_url" value="<?php echo e(old('video_url', $ad->video_url)); ?>" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2" placeholder="<?php echo app('translator')->get('messages.video_url_placeholder'); ?>">
        </div>

        <!-- تڼۍ -->
        <div class="flex items-center justify-between">
            <button type="submit" class="bg-indigo-600 text-white px-6 py-2 rounded-md hover:bg-indigo-700 transition"><?php echo app('translator')->get('messages.update'); ?></button>
            <a href="<?php echo e(route('admin.ads.index')); ?>" class="text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white"><?php echo app('translator')->get('messages.back'); ?></a>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Web For TA\gawhar-amu-travel\resources\views/admin/ads/edit.blade.php ENDPATH**/ ?>