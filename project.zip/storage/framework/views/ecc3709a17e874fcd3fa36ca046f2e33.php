

<?php $__env->startSection('content'); ?>
<div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
    <h1 class="text-3xl font-bold text-gray-800 mb-8">ګالري آیتم سمول</h1>

    <?php if($errors->any()): ?>
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-6">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('admin.galleries.update', $gallery)); ?>" method="POST" enctype="multipart/form-data" class="bg-white shadow-md rounded-lg p-8">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <!-- ډول -->
        <div class="mb-6">
            <label class="block text-gray-700 font-bold mb-2">ډول *</label>
            <select name="type" id="type" class="w-full border border-gray-300 rounded-md px-4 py-2" required onchange="toggleTypeFields()">
                <option value="image" <?php echo e(old('type', $gallery->type) == 'image' ? 'selected' : ''); ?>>انځور</option>
                <option value="video" <?php echo e(old('type', $gallery->type) == 'video' ? 'selected' : ''); ?>>ویډیو</option>
            </select>
        </div>

        <!-- د انځور برخه -->
        <div id="image-field" class="mb-6" style="<?php echo e(old('type', $gallery->type) == 'video' ? 'display:none;' : ''); ?>">
            <label class="block text-gray-700 font-bold mb-2">انځور</label>
            <?php if($gallery->type == 'image' && $gallery->url): ?>
                <div class="mb-3">
                    <img src="<?php echo e(asset('storage/' . $gallery->url)); ?>" alt="Current Image" class="h-20 w-20 object-cover rounded border">
                </div>
            <?php endif; ?>
            <input type="file" name="image" class="w-full border border-gray-300 rounded-md px-4 py-2">
        </div>

        <!-- د ویډیو برخه -->
        <div id="video-field" class="mb-6" style="<?php echo e(old('type', $gallery->type) == 'image' ? 'display:none;' : ''); ?>">
            <label class="block text-gray-700 font-bold mb-2">ویډیو لینک (YouTube)</label>
            <input type="url" name="video_url" value="<?php echo e(old('video_url', $gallery->type == 'video' ? $gallery->url : '')); ?>" class="w-full border border-gray-300 rounded-md px-4 py-2" placeholder="https://youtube.com/...">
        </div>

        <!-- توضیح (Caption) په دریو ژبو -->
        <div class="mb-6">
            <label class="block text-gray-700 font-bold mb-2">توضیح (پښتو)</label>
            <input type="text" name="caption_ps" value="<?php echo e(old('caption_ps', $gallery->caption['ps'] ?? '')); ?>" class="w-full border border-gray-300 rounded-md px-4 py-2">
        </div>
        <div class="mb-6">
            <label class="block text-gray-700 font-bold mb-2">توضیح (دری)</label>
            <input type="text" name="caption_dr" value="<?php echo e(old('caption_dr', $gallery->caption['dr'] ?? '')); ?>" class="w-full border border-gray-300 rounded-md px-4 py-2">
        </div>
        <div class="mb-6">
            <label class="block text-gray-700 font-bold mb-2">Caption (English)</label>
            <input type="text" name="caption_en" value="<?php echo e(old('caption_en', $gallery->caption['en'] ?? '')); ?>" class="w-full border border-gray-300 rounded-md px-4 py-2">
        </div>

        <!-- ترتیب -->
        <div class="mb-6">
            <label class="block text-gray-700 font-bold mb-2">ترتیب (Sort Order)</label>
            <input type="number" name="sort_order" value="<?php echo e(old('sort_order', $gallery->sort_order)); ?>" class="w-full border border-gray-300 rounded-md px-4 py-2">
        </div>

        <!-- فعال/غیرفعال -->
        <div class="mb-6">
            <label class="inline-flex items-center">
                <input type="checkbox" name="is_active" value="1" <?php echo e(old('is_active', $gallery->is_active) ? 'checked' : ''); ?> class="rounded border-gray-300 text-indigo-600 shadow-sm focus:ring-indigo-500">
                <span class="mr-2 text-gray-700 font-bold">فعال</span>
            </label>
        </div>

        <!-- تڼۍ -->
        <div class="flex items-center justify-between">
            <button type="submit" class="bg-indigo-600 text-white px-6 py-2 rounded-md hover:bg-indigo-700 transition">تازه کول</button>
            <a href="<?php echo e(route('admin.galleries.index')); ?>" class="text-gray-600 hover:text-gray-900">بېرته</a>
        </div>
    </form>
</div>

<script>
    function toggleTypeFields() {
        var type = document.getElementById('type').value;
        document.getElementById('image-field').style.display = (type === 'image') ? 'block' : 'none';
        document.getElementById('video-field').style.display = (type === 'video') ? 'block' : 'none';
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Web For TA\gawhar-amu-travel\resources\views/admin/galleries/edit.blade.php ENDPATH**/ ?>