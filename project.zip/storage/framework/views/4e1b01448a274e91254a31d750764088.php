
<?php $__env->startSection('content'); ?>
<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
    <h1 class="text-3xl font-bold mb-4" style="color: var(--body-text);"><?php echo app('translator')->get('messages.dashboard'); ?></h1>
    <p class="mb-8" style="color: var(--card-text);"><?php echo app('translator')->get('messages.welcome_user', ['name' => Auth::user()->name, 'role' => Auth::user()->role]); ?></p>

    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        <?php if(auth()->user()->hasPermissionTo('ads')): ?>
            <a href="<?php echo e(route('admin.ads.index')); ?>" class="block section-card hover:scale-105 transition duration-300">
                <h2 class="text-xl font-bold mb-2" style="color: var(--primary);">📋 <?php echo app('translator')->get('messages.ads'); ?></h2>
                <p style="color: var(--card-text);"><?php echo app('translator')->get('messages.ads_desc'); ?></p>
            </a>
        <?php endif; ?>

        
        <?php if(auth()->user()->hasPermissionTo('services')): ?>
            <a href="<?php echo e(route('admin.services.index')); ?>" class="block section-card hover:scale-105 transition duration-300">
                <h2 class="text-xl font-bold mb-2" style="color: #0d9488;">🛠️ <?php echo app('translator')->get('messages.services'); ?></h2>
                <p style="color: var(--card-text);"><?php echo app('translator')->get('messages.services_desc'); ?></p>
            </a>
        <?php endif; ?>

        
        <?php if(auth()->user()->hasPermissionTo('packages')): ?>
            <a href="<?php echo e(route('admin.packages.index')); ?>" class="block section-card hover:scale-105 transition duration-300">
                <h2 class="text-xl font-bold mb-2" style="color: #ea580c;">📦 <?php echo app('translator')->get('messages.packages'); ?></h2>
                <p style="color: var(--card-text);"><?php echo app('translator')->get('messages.packages_desc'); ?></p>
            </a>
        <?php endif; ?>

        
        <?php if(auth()->user()->hasPermissionTo('destinations')): ?>
            <a href="<?php echo e(route('admin.destinations.index')); ?>" class="block section-card hover:scale-105 transition duration-300">
                <h2 class="text-xl font-bold mb-2" style="color: #65a30d;">🌍 <?php echo app('translator')->get('messages.destinations'); ?></h2>
                <p style="color: var(--card-text);"><?php echo app('translator')->get('messages.destinations_desc'); ?></p>
            </a>
        <?php endif; ?>

        
        <?php if(auth()->user()->role === 'admin' || auth()->user()->hasPermissionTo('team')): ?>
            <a href="<?php echo e(route('admin.team.index')); ?>" class="block section-card hover:scale-105 transition duration-300">
                <h2 class="text-xl font-bold mb-2" style="color: #d97706;">👨‍💼 <?php echo app('translator')->get('messages.team'); ?></h2>
                <p style="color: var(--card-text);"><?php echo app('translator')->get('messages.team_desc'); ?></p>
            </a>
        <?php endif; ?>

        
        <?php if(auth()->user()->role === 'admin' || auth()->user()->hasPermissionTo('testimonials')): ?>
            <a href="<?php echo e(route('admin.testimonials.index')); ?>" class="block section-card hover:scale-105 transition duration-300">
                <h2 class="text-xl font-bold mb-2" style="color: #e11d48;">🗣️ <?php echo app('translator')->get('messages.testimonials'); ?></h2>
                <p style="color: var(--card-text);"><?php echo app('translator')->get('messages.testimonials_desc'); ?></p>
            </a>
        <?php endif; ?>

        
        <?php if(auth()->user()->role === 'admin' || auth()->user()->hasPermissionTo('faqs')): ?>
            <a href="<?php echo e(route('admin.faqs.index')); ?>" class="block section-card hover:scale-105 transition duration-300">
                <h2 class="text-xl font-bold mb-2" style="color: #0891b2;">❓ <?php echo app('translator')->get('messages.faq'); ?></h2>
                <p style="color: var(--card-text);"><?php echo app('translator')->get('messages.faq_desc'); ?></p>
            </a>
        <?php endif; ?>

        
        <?php if(auth()->user()->role === 'admin' || auth()->user()->hasPermissionTo('gallery')): ?>
            <a href="<?php echo e(route('admin.galleries.index')); ?>" class="block section-card hover:scale-105 transition duration-300">
                <h2 class="text-xl font-bold mb-2" style="color: #db2777;">🖼️ <?php echo app('translator')->get('messages.gallery'); ?></h2>
                <p style="color: var(--card-text);"><?php echo app('translator')->get('messages.gallery_desc'); ?></p>
            </a>
        <?php endif; ?>

        
        <?php if(auth()->user()->role === 'admin' || auth()->user()->hasPermissionTo('messages')): ?>
            <a href="<?php echo e(route('admin.messages.index')); ?>" class="block section-card hover:scale-105 transition duration-300">
                <h2 class="text-xl font-bold mb-2" style="color: #4f46e5;">📩 <?php echo app('translator')->get('messages.messages'); ?></h2>
                <p style="color: var(--card-text);"><?php echo app('translator')->get('messages.messages_desc'); ?></p>
            </a>
        <?php endif; ?>

        
        <?php if(Auth::user()->role === 'admin'): ?>
            <a href="<?php echo e(route('admin.users.index')); ?>" class="block section-card hover:scale-105 transition duration-300">
                <h2 class="text-xl font-bold mb-2" style="color: #7c3aed;">👥 <?php echo app('translator')->get('messages.users'); ?></h2>
                <p style="color: var(--card-text);"><?php echo app('translator')->get('messages.users_desc'); ?></p>
            </a>
        <?php endif; ?>

        
        <?php if(Auth::user()->role === 'admin'): ?>
            <a href="<?php echo e(route('admin.settings.index')); ?>" class="block section-card hover:scale-105 transition duration-300">
                <h2 class="text-xl font-bold mb-2" style="color: #16a34a;">⚙️ <?php echo app('translator')->get('messages.settings'); ?></h2>
                <p style="color: var(--card-text);"><?php echo app('translator')->get('messages.settings_desc'); ?></p>
            </a>
        <?php endif; ?>

        
        <a href="<?php echo e(route('change.password.form')); ?>" class="block section-card hover:scale-105 transition duration-300">
            <h2 class="text-xl font-bold mb-2" style="color: #ca8a04;">🔒 <?php echo app('translator')->get('messages.change_password'); ?></h2>
            <p style="color: var(--card-text);"><?php echo app('translator')->get('messages.change_password_desc'); ?></p>
        </a>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Web For TA\gawhar-amu-travel\resources\views/dashboard.blade.php ENDPATH**/ ?>