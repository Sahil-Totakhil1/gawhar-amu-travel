

<?php $__env->startSection('content'); ?>
<div class="max-w-4xl mx-auto">
    <h1 class="text-3xl font-bold mb-8 dark:text-white text-gray-800"><?php echo app('translator')->get('messages.create_gallery_title'); ?></h1>

    <?php if($errors->any()): ?>
        <div class="bg-red-100 dark:bg-red-800 border border-red-400 dark:border-red-600 text-red-700 dark:text-red-200 px-4 py-3 rounded mb-6">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('admin.galleries.store')); ?>" method="POST" enctype="multipart/form-data" class="bg-white dark:bg-gray-800 shadow-md rounded-lg p-8">
        <?php echo csrf_field(); ?>

        <!-- ډول -->
        <div class="mb-6">
            <label class="block text-gray-700 dark:text-gray-300 font-bold mb-2"><?php echo app('translator')->get('messages.type'); ?> *</label>
            <select name="type" id="type" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2" required onchange="toggleTypeFields()">
                <option value="image" <?php echo e(old('type') == 'image' ? 'selected' : ''); ?>><?php echo app('translator')->get('messages.image'); ?></option>
                <option value="video" <?php echo e(old('type') == 'video' ? 'selected' : ''); ?>><?php echo app('translator')->get('messages.video'); ?></option>
            </select>
        </div>

        <!-- د انځور برخه -->
        <div id="image-field" class="mb-6">
            <label class="block text-gray-700 dark:text-gray-300 font-bold mb-2"><?php echo app('translator')->get('messages.image'); ?></label>
            <input type="file" name="image" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2" accept="image/*">
            <p class="text-xs text-gray-500 dark:text-gray-400 mt-1"><?php echo app('translator')->get('messages.image_requirements'); ?></p>
        </div>

        <!-- د ویډیو برخه -->
        <div id="video-field" class="mb-6" style="display: none;">
            <label class="block text-gray-700 dark:text-gray-300 font-bold mb-2"><?php echo app('translator')->get('messages.video_url'); ?></label>
            <input type="url" name="video_url" value="<?php echo e(old('video_url')); ?>" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2" placeholder="<?php echo app('translator')->get('messages.video_url_placeholder'); ?>">
        </div>

        <!-- توضیح (Caption) په دریو ژبو -->
        <div class="mb-6">
            <label class="block text-gray-700 dark:text-gray-300 font-bold mb-2"><?php echo app('translator')->get('messages.caption_ps'); ?></label>
            <input type="text" name="caption_ps" value="<?php echo e(old('caption_ps')); ?>" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2">
        </div>
        <div class="mb-6">
            <label class="block text-gray-700 dark:text-gray-300 font-bold mb-2"><?php echo app('translator')->get('messages.caption_dr'); ?></label>
            <input type="text" name="caption_dr" value="<?php echo e(old('caption_dr')); ?>" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2">
        </div>
        <div class="mb-6">
            <label class="block text-gray-700 dark:text-gray-300 font-bold mb-2"><?php echo app('translator')->get('messages.caption_en'); ?></label>
            <input type="text" name="caption_en" value="<?php echo e(old('caption_en')); ?>" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2">
        </div>

        <!-- ترتیب -->
        <div class="mb-6">
            <label class="block text-gray-700 dark:text-gray-300 font-bold mb-2"><?php echo app('translator')->get('messages.sort_order'); ?></label>
            <input type="number" name="sort_order" value="<?php echo e(old('sort_order', 0)); ?>" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2">
        </div>

        <!-- تڼۍ -->
        <div class="flex items-center justify-between">
            <button type="submit" class="bg-blue-600 text-white px-6 py-2 rounded-md hover:bg-blue-700 transition"><?php echo app('translator')->get('messages.save'); ?></button>
            <a href="<?php echo e(route('admin.galleries.index')); ?>" class="text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white"><?php echo app('translator')->get('messages.back'); ?></a>
        </div>
    </form>
</div>

<script>
    function toggleTypeFields() {
        var type = document.getElementById('type').value;
        document.getElementById('image-field').style.display = (type === 'image') ? 'block' : 'none';
        document.getElementById('video-field').style.display = (type === 'video') ? 'block' : 'none';
    }
    // د پخواني انتخاب پر بنسټ د پاڼې د بارېدو پر مهال حالت
    document.addEventListener('DOMContentLoaded', function() {
        toggleTypeFields();
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Web For TA\gawhar-amu-travel\resources\views/admin/galleries/create.blade.php ENDPATH**/ ?>