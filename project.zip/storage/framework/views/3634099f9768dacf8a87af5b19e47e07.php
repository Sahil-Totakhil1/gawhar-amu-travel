

<?php $__env->startSection('content'); ?>
<div class="max-w-4xl mx-auto">
    <h1 class="text-3xl font-bold mb-8 dark:text-white text-gray-800"><?php echo app('translator')->get('messages.new_user_title'); ?></h1>

    <?php if($errors->any()): ?>
        <div class="bg-red-100 dark:bg-red-800 border border-red-400 dark:border-red-600 text-red-700 dark:text-red-200 px-4 py-3 rounded mb-6">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('admin.users.store')); ?>" method="POST" class="bg-white dark:bg-gray-800 shadow-md rounded-lg p-8">
        <?php echo csrf_field(); ?>

        <!-- نوم -->
        <div class="mb-6">
            <label class="block text-gray-700 dark:text-gray-300 font-bold mb-2"><?php echo app('translator')->get('messages.name'); ?> *</label>
            <input type="text" name="name" value="<?php echo e(old('name')); ?>" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2" required>
        </div>

        <!-- یوزرنیم -->
        <div class="mb-6">
            <label class="block text-gray-700 dark:text-gray-300 font-bold mb-2"><?php echo app('translator')->get('messages.username'); ?> *</label>
            <input type="text" name="username" value="<?php echo e(old('username')); ?>" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2" required>
        </div>

        <!-- ایمیل -->
        <div class="mb-6">
            <label class="block text-gray-700 dark:text-gray-300 font-bold mb-2"><?php echo app('translator')->get('messages.email_optional'); ?></label>
            <input type="email" name="email" value="<?php echo e(old('email')); ?>" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2">
        </div>

        <!-- تلیفون -->
        <div class="mb-6">
            <label class="block text-gray-700 dark:text-gray-300 font-bold mb-2"><?php echo app('translator')->get('messages.phone_optional'); ?></label>
            <input type="text" name="phone" value="<?php echo e(old('phone')); ?>" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2">
        </div>

        <!-- پاسورډ -->
        <div class="mb-6">
            <label class="block text-gray-700 dark:text-gray-300 font-bold mb-2"><?php echo app('translator')->get('messages.password_requirements'); ?></label>
            <div class="relative">
                <input type="password" name="password" id="password" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2 pr-12" required minlength="8" onkeyup="checkPasswordStrength()">
                <span class="absolute inset-y-0 right-0 flex items-center pr-3 cursor-pointer" onclick="togglePasswordVisibility('password', 'eyeIcon')">
                    <i id="eyeIcon" class="fas fa-eye text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-white"></i>
                </span>
            </div>
            
            <div class="mt-2" id="password-strength">
                <div class="flex gap-1 mt-1">
                    <div id="strength-bar-1" class="h-1 w-1/4 bg-gray-300 rounded"></div>
                    <div id="strength-bar-2" class="h-1 w-1/4 bg-gray-300 rounded"></div>
                    <div id="strength-bar-3" class="h-1 w-1/4 bg-gray-300 rounded"></div>
                    <div id="strength-bar-4" class="h-1 w-1/4 bg-gray-300 rounded"></div>
                </div>
                <p id="strength-text" class="text-xs text-gray-500 dark:text-gray-400 mt-1"><?php echo app('translator')->get('messages.password_write'); ?></p>
            </div>
            
            <div class="mt-2 text-xs text-gray-500 dark:text-gray-400">
                <p id="length-check" class="text-red-500">✗ <?php echo app('translator')->get('messages.pw_length'); ?></p>
                <p id="lowercase-check" class="text-red-500">✗ <?php echo app('translator')->get('messages.pw_lowercase'); ?></p>
                <p id="uppercase-check" class="text-red-500">✗ <?php echo app('translator')->get('messages.pw_uppercase'); ?></p>
                <p id="number-check" class="text-red-500">✗ <?php echo app('translator')->get('messages.pw_number'); ?></p>
                <p id="special-check" class="text-red-500">✗ <?php echo app('translator')->get('messages.pw_special'); ?></p>
            </div>
        </div>

        <!-- رول -->
        <div class="mb-6">
            <label class="block text-gray-700 dark:text-gray-300 font-bold mb-2"><?php echo app('translator')->get('messages.role'); ?> *</label>
            <select name="role" id="role" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2" required>
                <option value="admin" <?php echo e(old('role') == 'admin' ? 'selected' : ''); ?>><?php echo app('translator')->get('messages.admin'); ?></option>
                <option value="staff" <?php echo e(old('role') == 'staff' ? 'selected' : ''); ?>><?php echo app('translator')->get('messages.staff'); ?></option>
            </select>
        </div>

        <!-- واک (یوازې د Staff لپاره) -->
        <div class="mb-6" id="permission-field">
            <label class="block text-gray-700 dark:text-gray-300 font-bold mb-2"><?php echo app('translator')->get('messages.permission_for_staff'); ?></label>
            <select name="permission" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2">
                <option value=""><?php echo app('translator')->get('messages.all_permissions_select'); ?></option>
                <option value="ads" <?php echo e(old('permission') == 'ads' ? 'selected' : ''); ?>><?php echo app('translator')->get('messages.ads'); ?></option>
                <option value="packages" <?php echo e(old('permission') == 'packages' ? 'selected' : ''); ?>><?php echo app('translator')->get('messages.packages'); ?></option>
                <option value="services" <?php echo e(old('permission') == 'services' ? 'selected' : ''); ?>><?php echo app('translator')->get('messages.services'); ?></option>
                <option value="destinations" <?php echo e(old('permission') == 'destinations' ? 'selected' : ''); ?>><?php echo app('translator')->get('messages.destinations'); ?></option>
            </select>
        </div>

        <!-- فعال / غیرفعال -->
        <div class="mb-6">
            <label class="block text-gray-700 dark:text-gray-300 font-bold mb-2"><?php echo app('translator')->get('messages.status'); ?></label>
            <select name="is_active" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2">
                <option value="1" <?php echo e(old('is_active') == '1' ? 'selected' : ''); ?>><?php echo app('translator')->get('messages.active'); ?></option>
                <option value="0" <?php echo e(old('is_active') == '0' ? 'selected' : ''); ?>><?php echo app('translator')->get('messages.inactive'); ?></option>
            </select>
        </div>

        <!-- تڼۍ -->
        <div class="flex items-center justify-between">
            <button type="submit" class="bg-blue-600 text-white px-6 py-2 rounded-md hover:bg-blue-700 transition"><?php echo app('translator')->get('messages.save'); ?></button>
            <a href="<?php echo e(route('admin.users.index')); ?>" class="text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white"><?php echo app('translator')->get('messages.back'); ?></a>
        </div>
    </form>
</div>

<script>
    // د سترګې آیکون: پاسورډ ښکاره/پټول
    function togglePasswordVisibility(inputId, iconId) {
        var p = document.getElementById(inputId);
        var icon = document.getElementById(iconId);
        if (p.type === 'password') {
            p.type = 'text';
            icon.classList.remove('fa-eye');
            icon.classList.add('fa-eye-slash');
        } else {
            p.type = 'password';
            icon.classList.remove('fa-eye-slash');
            icon.classList.add('fa-eye');
        }
    }

    // د پاسورډ د قوت چک کول
    function checkPasswordStrength() {
        var password = document.getElementById('password').value;
        var lengthCheck = document.getElementById('length-check');
        var lowercaseCheck = document.getElementById('lowercase-check');
        var uppercaseCheck = document.getElementById('uppercase-check');
        var numberCheck = document.getElementById('number-check');
        var specialCheck = document.getElementById('special-check');
        
        var lengthValid = password.length >= 8;
        var lowercaseValid = /[a-z]/.test(password);
        var uppercaseValid = /[A-Z]/.test(password);
        var numberValid = /[0-9]/.test(password);
        var specialValid = /[@$!%*?&]/.test(password);
        
        lengthCheck.innerHTML = lengthValid ? '✓ <?php echo app('translator')->get("messages.pw_length"); ?>' : '✗ <?php echo app('translator')->get("messages.pw_length"); ?>';
        lengthCheck.className = lengthValid ? 'text-green-600' : 'text-red-500';
        lowercaseCheck.innerHTML = lowercaseValid ? '✓ <?php echo app('translator')->get("messages.pw_lowercase"); ?>' : '✗ <?php echo app('translator')->get("messages.pw_lowercase"); ?>';
        lowercaseCheck.className = lowercaseValid ? 'text-green-600' : 'text-red-500';
        uppercaseCheck.innerHTML = uppercaseValid ? '✓ <?php echo app('translator')->get("messages.pw_uppercase"); ?>' : '✗ <?php echo app('translator')->get("messages.pw_uppercase"); ?>';
        uppercaseCheck.className = uppercaseValid ? 'text-green-600' : 'text-red-500';
        numberCheck.innerHTML = numberValid ? '✓ <?php echo app('translator')->get("messages.pw_number"); ?>' : '✗ <?php echo app('translator')->get("messages.pw_number"); ?>';
        numberCheck.className = numberValid ? 'text-green-600' : 'text-red-500';
        specialCheck.innerHTML = specialValid ? '✓ <?php echo app('translator')->get("messages.pw_special"); ?>' : '✗ <?php echo app('translator')->get("messages.pw_special"); ?>';
        specialCheck.className = specialValid ? 'text-green-600' : 'text-red-500';
        
        var strength = 0;
        if (lengthValid) strength++;
        if (lowercaseValid && uppercaseValid) strength++;
        if (numberValid) strength++;
        if (specialValid) strength++;
        
        var bars = [
            document.getElementById('strength-bar-1'),
            document.getElementById('strength-bar-2'),
            document.getElementById('strength-bar-3'),
            document.getElementById('strength-bar-4')
        ];
        var strengthText = document.getElementById('strength-text');
        var colors = ['bg-gray-300', 'bg-red-500', 'bg-yellow-500', 'bg-green-500', 'bg-green-600'];
        var texts = [
            '<?php echo app('translator')->get("messages.pw_very_weak"); ?>',
            '<?php echo app('translator')->get("messages.pw_weak"); ?>',
            '<?php echo app('translator')->get("messages.pw_medium"); ?>',
            '<?php echo app('translator')->get("messages.pw_strong"); ?>',
            '<?php echo app('translator')->get("messages.pw_very_strong"); ?>'
        ];
        for (var i = 0; i < bars.length; i++) {
            bars[i].className = 'h-1 w-1/4 rounded ' + (i < strength ? colors[strength] : 'bg-gray-300');
        }
        if (strength === 0) {
            strengthText.innerText = '<?php echo app('translator')->get("messages.password_write"); ?>';
        } else {
            strengthText.innerText = texts[strength];
            strengthText.className = 'text-xs mt-1 ' + (strength >= 3 ? 'text-green-600 font-bold' : 'text-gray-500');
        }
    }

    document.getElementById('role').addEventListener('change', function() {
        var perm = document.getElementById('permission-field');
        perm.style.display = (this.value === 'admin') ? 'none' : 'block';
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Web For TA\gawhar-amu-travel\resources\views/admin/users/create.blade.php ENDPATH**/ ?>