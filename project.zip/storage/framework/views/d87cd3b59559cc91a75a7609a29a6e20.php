

<?php $__env->startSection('content'); ?>
<div class="max-w-7xl mx-auto">
    <div class="flex justify-between items-center mb-8">
        <h1 class="text-3xl font-bold dark:text-white text-gray-800"><?php echo app('translator')->get('messages.all_destinations'); ?></h1>
        
        
        <?php if(auth()->user()->hasPermissionTo('destinations')): ?>
            <a href="<?php echo e(route('admin.destinations.create')); ?>" class="bg-blue-600 text-white px-6 py-2 rounded-md hover:bg-blue-700 transition">
                <?php echo app('translator')->get('messages.new_destination'); ?>
            </a>
        <?php endif; ?>
    </div>

    <?php if(session('success')): ?>
        <div class="bg-green-100 dark:bg-green-800 border border-green-400 dark:border-green-600 text-green-700 dark:text-green-200 px-4 py-3 rounded mb-6">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if($destinations->count() > 0): ?>
        <div class="bg-white dark:bg-gray-800 shadow overflow-hidden sm:rounded-lg">
            <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                <thead class="bg-gray-50 dark:bg-gray-700">
                    <tr>
                        <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-300 uppercase"><?php echo app('translator')->get('messages.image'); ?></th>
                        <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-300 uppercase"><?php echo app('translator')->get('messages.title'); ?></th>
                        <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-300 uppercase"><?php echo app('translator')->get('messages.description'); ?></th>
                        <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-300 uppercase"><?php echo app('translator')->get('messages.status'); ?></th>
                        <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-300 uppercase"><?php echo app('translator')->get('messages.actions'); ?></th>
                    </tr>
                </thead>
                <tbody class="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                    <?php $__currentLoopData = $destinations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $destination): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="hover:bg-gray-50 dark:hover:bg-gray-700 transition">
                        <td class="px-6 py-4 whitespace-nowrap">
                            <?php if($destination->image): ?>
                                <img src="<?php echo e(asset('storage/' . $destination->image)); ?>" class="h-10 w-10 object-cover rounded">
                            <?php else: ?>
                                <span class="text-gray-400 dark:text-gray-500">--</span>
                            <?php endif; ?>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-gray-100">
                            <?php echo e($destination->title[app()->getLocale()] ?? $destination->title['ps'] ?? ''); ?>

                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                            <?php echo e(Str::limit($destination->description[app()->getLocale()] ?? $destination->description['ps'] ?? '', 50)); ?>

                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full <?php echo e($destination->is_active ? 'bg-green-100 text-green-800 dark:bg-green-800 dark:text-green-200' : 'bg-red-100 text-red-800 dark:bg-red-800 dark:text-red-200'); ?>">
                                <?php echo e($destination->is_active ? __('messages.active') : __('messages.inactive')); ?>

                            </span>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2 rtl:space-x-reverse">
                            
                            <?php if(auth()->user()->hasPermissionTo('destinations')): ?>
                                <a href="<?php echo e(route('admin.destinations.edit', $destination)); ?>" class="text-indigo-600 hover:text-indigo-900 dark:text-indigo-400 dark:hover:text-indigo-300"><?php echo app('translator')->get('messages.edit'); ?></a>
                            <?php endif; ?>

                            
                            <?php if(auth()->user()->hasPermissionTo('destinations')): ?>
                                <form action="<?php echo e(route('admin.destinations.destroy', $destination)); ?>" method="POST" class="inline">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="text-red-600 hover:text-red-900 dark:text-red-400 dark:hover:text-red-300" onclick="return confirm('<?php echo app('translator')->get('messages.confirm_delete'); ?>')"><?php echo app('translator')->get('messages.delete'); ?></button>
                                </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div class="mt-6">
            <?php echo e($destinations->links()); ?>

        </div>
    <?php else: ?>
        <div class="bg-white dark:bg-gray-800 shadow-md rounded-lg p-8 text-center">
            <p class="text-gray-500 dark:text-gray-400 text-lg"><?php echo app('translator')->get('messages.no_destinations'); ?></p>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Web For TA\gawhar-amu-travel\resources\views/admin/destinations/index.blade.php ENDPATH**/ ?>