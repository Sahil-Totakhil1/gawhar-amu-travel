

<?php $__env->startSection('content'); ?>
<div class="max-w-4xl mx-auto">
    <h1 class="text-3xl font-bold mb-8 dark:text-white text-gray-800"><?php echo app('translator')->get('messages.new_testimonial_title'); ?></h1>

    <?php if($errors->any()): ?>
        <div class="bg-red-100 dark:bg-red-800 border border-red-400 dark:border-red-600 text-red-700 dark:text-red-200 px-4 py-3 rounded mb-6">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('admin.testimonials.store')); ?>" method="POST" enctype="multipart/form-data" class="bg-white dark:bg-gray-800 shadow-md rounded-lg p-8">
        <?php echo csrf_field(); ?>

        <!-- نوم -->
        <div class="mb-6">
            <label class="block text-gray-700 dark:text-gray-300 font-bold mb-2"><?php echo app('translator')->get('messages.name'); ?> *</label>
            <input type="text" name="name" value="<?php echo e(old('name')); ?>" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2" required>
        </div>

        <!-- نظر -->
        <div class="mb-6">
            <label class="block text-gray-700 dark:text-gray-300 font-bold mb-2"><?php echo app('translator')->get('messages.comment_label'); ?></label>
            <textarea name="comment" rows="4" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2" required><?php echo e(old('comment')); ?></textarea>
        </div>

        <!-- انځور (اختیاري) -->
        <div class="mb-6">
            <label class="block text-gray-700 dark:text-gray-300 font-bold mb-2"><?php echo app('translator')->get('messages.image_optional_label'); ?></label>
            <input type="file" name="image" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2" accept="image/*">
            <p class="text-xs text-gray-500 dark:text-gray-400 mt-1"><?php echo app('translator')->get('messages.image_requirements'); ?></p>
        </div>

        <!-- ستوري -->
        <div class="mb-6">
            <label class="block text-gray-700 dark:text-gray-300 font-bold mb-2"><?php echo app('translator')->get('messages.rating_label'); ?></label>
            <select name="rating" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2" required>
                <option value="5" <?php echo e(old('rating') == '5' ? 'selected' : ''); ?>><?php echo app('translator')->get('messages.rating_5'); ?></option>
                <option value="4" <?php echo e(old('rating') == '4' ? 'selected' : ''); ?>><?php echo app('translator')->get('messages.rating_4'); ?></option>
                <option value="3" <?php echo e(old('rating') == '3' ? 'selected' : ''); ?>><?php echo app('translator')->get('messages.rating_3'); ?></option>
                <option value="2" <?php echo e(old('rating') == '2' ? 'selected' : ''); ?>><?php echo app('translator')->get('messages.rating_2'); ?></option>
                <option value="1" <?php echo e(old('rating') == '1' ? 'selected' : ''); ?>><?php echo app('translator')->get('messages.rating_1'); ?></option>
            </select>
        </div>

        <!-- تڼۍ -->
        <div class="flex items-center justify-between">
            <button type="submit" class="bg-blue-600 text-white px-6 py-2 rounded-md hover:bg-blue-700 transition"><?php echo app('translator')->get('messages.save'); ?></button>
            <a href="<?php echo e(route('admin.testimonials.index')); ?>" class="text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white"><?php echo app('translator')->get('messages.back'); ?></a>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Web For TA\gawhar-amu-travel\resources\views/admin/testimonials/create.blade.php ENDPATH**/ ?>