

<?php $__env->startSection('content'); ?>
<div class="py-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <h1 class="text-4xl font-bold text-center mb-12" style="background: linear-gradient(45deg, var(--primary), var(--secondary)); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">
        <?php echo app('translator')->get('messages.ads'); ?>
    </h1>

    <?php if(isset($categories)): ?>
    <div class="flex justify-center mb-12 flex-wrap gap-3">
        <a href="<?php echo e(route('ads.index')); ?>" 
           class="px-5 py-2 rounded-full text-sm font-medium transition duration-300 
                  <?php echo e(!request('category') ? 'btn-primary' : ''); ?>"
           style="<?php echo e(!request('category') ? '' : 'background: var(--glass-bg); border: 1px solid var(--glass-border); color: var(--body-text);'); ?>">
            <?php echo app('translator')->get('messages.all'); ?>
        </a>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(route('ads.index', ['category' => $cat])); ?>" 
           class="px-5 py-2 rounded-full text-sm font-medium transition duration-300 
                  <?php echo e(request('category') == $cat ? 'btn-primary' : ''); ?>"
           style="<?php echo e(request('category') == $cat ? '' : 'background: var(--glass-bg); border: 1px solid var(--glass-border); color: var(--body-text);'); ?>">
            <?php echo e($cat); ?>

        </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php endif; ?>

    <?php if($ads->count() > 0): ?>
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            <?php $__currentLoopData = $ads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="section-card overflow-hidden hover:scale-105 transition duration-300 card-3d"
                 data-aos="fade-up" data-aos-delay="<?php echo e($loop->index * 100); ?>"
                 onmousemove="tiltCard(event, this)" onmouseleave="resetTilt(this)">
                <?php if($ad->video_url): ?>
                    <div class="relative" style="padding-top: 56.25%">
                        <iframe class="absolute inset-0 w-full h-full" src="<?php echo e($ad->video_url); ?>" frameborder="0" allowfullscreen></iframe>
                    </div>
                <?php elseif($ad->image): ?>
                    <img src="<?php echo e(asset('storage/' . $ad->image)); ?>" alt="<?php echo e($ad->title['ps'] ?? ''); ?>" class="w-full h-52 object-cover">
                <?php else: ?>
                    <div class="w-full h-52 flex items-center justify-center" style="background: var(--card-bg); color: var(--card-text);"><?php echo app('translator')->get('messages.no_image'); ?></div>
                <?php endif; ?>
                <div class="p-6">
                    <h3 class="text-xl font-bold mb-2" style="color: var(--card-heading);"><?php echo e($ad->title[app()->getLocale()] ?? $ad->title['ps'] ?? ''); ?></h3>
                    <p class="mb-4 text-sm" style="color: var(--card-text);"><?php echo e(Str::limit($ad->description[app()->getLocale()] ?? $ad->description['ps'] ?? '', 80)); ?></p>
                    <div class="flex items-center text-sm mb-4" style="color: var(--card-text);">
                        <?php if($ad->price): ?> <span class="mr-4 font-bold" style="color: var(--primary);">$<?php echo e($ad->price); ?></span> <?php endif; ?>
                        <?php if($ad->location): ?> <span><i class="fas fa-map-marker-alt" style="color: var(--primary);"></i> <?php echo e($ad->location); ?></span> <?php endif; ?>
                    </div>
                    <div class="flex justify-between items-center pt-4 border-t" style="border-color: var(--glass-border);">
                        <span class="text-xs" style="color: var(--card-text);">👁 <?php echo e($ad->views); ?> <?php echo app('translator')->get('messages.views'); ?></span>
                        <a href="<?php echo e(route('ads.show', $ad)); ?>" class="btn-primary px-4 py-2 rounded-full text-sm font-semibold inline-block"><?php echo app('translator')->get('messages.details'); ?></a>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="mt-12">
            <?php echo e($ads->links()); ?>

        </div>
    <?php else: ?>
        <div class="text-center py-20">
            <div class="text-6xl mb-6" style="color: var(--card-text);">📋</div>
            <p class="text-xl" style="color: var(--card-text);"><?php echo app('translator')->get('messages.no_ads'); ?></p>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    function tiltCard(event, card) {
        const rect = card.getBoundingClientRect();
        const x = event.clientX - rect.left;
        const y = event.clientY - rect.top;
        const halfWidth = rect.width / 2;
        const halfHeight = rect.height / 2;
        const angleX = -(y - halfHeight) / 10;
        const angleY = (x - halfWidth) / 10;
        card.style.transform = `perspective(1000px) rotateX(${angleX}deg) rotateY(${angleY}deg) scale(1.02)`;
    }
    function resetTilt(card) {
        card.style.transform = 'perspective(1000px) rotateX(0deg) rotateY(0deg) scale(1)';
    }
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Web For TA\gawhar-amu-travel\resources\views/frontend/ads/index.blade.php ENDPATH**/ ?>