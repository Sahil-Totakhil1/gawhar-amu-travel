

<?php $__env->startSection('content'); ?>
<div class="max-w-4xl mx-auto">
    <h1 class="text-3xl font-bold mb-8 dark:text-white text-gray-800"><?php echo app('translator')->get('messages.new_destination_title'); ?></h1>

    <?php if($errors->any()): ?>
        <div class="bg-red-100 dark:bg-red-800 border border-red-400 dark:border-red-600 text-red-700 dark:text-red-200 px-4 py-3 rounded mb-6">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('admin.destinations.store')); ?>" method="POST" enctype="multipart/form-data" class="bg-white dark:bg-gray-800 shadow-md rounded-lg p-8">
        <?php echo csrf_field(); ?>

        <!-- عنوان (پښتو) -->
        <div class="mb-6">
            <label class="block text-gray-700 dark:text-gray-300 font-bold mb-2"><?php echo app('translator')->get('messages.title_ps'); ?> *</label>
            <input type="text" name="title_ps" value="<?php echo e(old('title_ps')); ?>" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2" required>
        </div>
        <!-- عنوان (دری) -->
        <div class="mb-6">
            <label class="block text-gray-700 dark:text-gray-300 font-bold mb-2"><?php echo app('translator')->get('messages.title_dr'); ?></label>
            <input type="text" name="title_dr" value="<?php echo e(old('title_dr')); ?>" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2">
        </div>
        <!-- Title (English) -->
        <div class="mb-6">
            <label class="block text-gray-700 dark:text-gray-300 font-bold mb-2"><?php echo app('translator')->get('messages.title_en'); ?></label>
            <input type="text" name="title_en" value="<?php echo e(old('title_en')); ?>" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2">
        </div>

        <!-- تشریح (پښتو) -->
        <div class="mb-6">
            <label class="block text-gray-700 dark:text-gray-300 font-bold mb-2"><?php echo app('translator')->get('messages.description_ps'); ?></label>
            <textarea name="description_ps" rows="3" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2"><?php echo e(old('description_ps')); ?></textarea>
        </div>
        <!-- تشریح (دری) -->
        <div class="mb-6">
            <label class="block text-gray-700 dark:text-gray-300 font-bold mb-2"><?php echo app('translator')->get('messages.description_dr'); ?></label>
            <textarea name="description_dr" rows="3" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2"><?php echo e(old('description_dr')); ?></textarea>
        </div>
        <!-- Description (English) -->
        <div class="mb-6">
            <label class="block text-gray-700 dark:text-gray-300 font-bold mb-2"><?php echo app('translator')->get('messages.description_en'); ?></label>
            <textarea name="description_en" rows="3" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2"><?php echo e(old('description_en')); ?></textarea>
        </div>

        <!-- انځور -->
        <div class="mb-6">
            <label class="block text-gray-700 dark:text-gray-300 font-bold mb-2"><?php echo app('translator')->get('messages.image'); ?></label>
            <input type="file" name="image" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2">
            <p class="text-xs text-gray-500 dark:text-gray-400 mt-1"><?php echo app('translator')->get('messages.image_requirements'); ?></p>
        </div>

        <!-- تڼۍ -->
        <div class="flex items-center justify-between">
            <button type="submit" class="bg-blue-600 text-white px-6 py-2 rounded-md hover:bg-blue-700 transition"><?php echo app('translator')->get('messages.save'); ?></button>
            <a href="<?php echo e(route('admin.destinations.index')); ?>" class="text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white"><?php echo app('translator')->get('messages.back'); ?></a>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Web For TA\gawhar-amu-travel\resources\views/admin/destinations/create.blade.php ENDPATH**/ ?>