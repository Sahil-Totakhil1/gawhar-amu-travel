

<?php $__env->startSection('content'); ?>
<div class="py-12 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <h1 class="text-3xl font-bold text-center text-primary mb-12"><?php echo app('translator')->get('messages.packages'); ?></h1>
    <?php if($packages->count() > 0): ?>
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-xl transition" data-aos="fade-up" data-aos-delay="<?php echo e($loop->index * 100); ?>">
                <?php if($package->image): ?>
                    <img src="<?php echo e(asset('storage/' . $package->image)); ?>" alt="<?php echo e($package->title['ps'] ?? ''); ?>" class="w-full h-48 object-cover">
                <?php else: ?>
                    <div class="w-full h-48 bg-gray-200 flex items-center justify-center text-gray-400">انځور نشته</div>
                <?php endif; ?>
                <div class="p-6">
                    <h3 class="text-xl font-bold text-gray-800 mb-2">
                        <?php echo e($package->title[app()->getLocale()] ?? $package->title['ps']); ?>

                    </h3>
                    <div class="flex items-center text-gray-600 mb-2">
                        <?php if($package->destination): ?>
                            <span class="mr-3">📍 <?php echo e($package->destination); ?></span>
                        <?php endif; ?>
                        <?php if($package->duration): ?>
                            <span>⏱️ <?php echo e($package->duration); ?></span>
                        <?php endif; ?>
                    </div>
                    <p class="text-gray-600 mb-4">
                        <?php echo e(Str::limit($package->description[app()->getLocale()] ?? $package->description['ps'] ?? '', 80)); ?>

                    </p>
                    <?php if($package->price): ?>
                        <div class="text-2xl font-bold text-green-600">$<?php echo e($package->price); ?></div>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="mt-10">
            <?php echo e($packages->links()); ?>

        </div>
    <?php else: ?>
        <p class="text-center text-gray-500">تر اوسه کوم پکېج نه دی اضافه شوی.</p>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Web For TA\gawhar-amu-travel\resources\views/frontend/packages.blade.php ENDPATH**/ ?>