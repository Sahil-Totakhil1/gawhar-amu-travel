

<?php $__env->startSection('content'); ?>
<div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
    <a href="<?php echo e(route('ads.index')); ?>" class="inline-flex items-center gap-2 mb-6 transition" style="color: var(--primary);">
        <i class="fas fa-arrow-right rtl:rotate-180"></i> <?php echo app('translator')->get('messages.back_to_ads'); ?>
    </a>

    <div class="section-card overflow-hidden">
        <?php if($ad->video_url): ?>
            <div class="relative" style="padding-top: 56.25%">
                <iframe class="absolute inset-0 w-full h-full" src="<?php echo e($ad->video_url); ?>" frameborder="0" allowfullscreen></iframe>
            </div>
        <?php elseif($ad->image): ?>
            <img src="<?php echo e(asset('storage/' . $ad->image)); ?>" alt="<?php echo e($ad->title['ps'] ?? ''); ?>" class="w-full h-72 object-cover">
        <?php else: ?>
            <div class="w-full h-72 flex items-center justify-center" style="background: var(--card-bg); color: var(--card-text);"><?php echo app('translator')->get('messages.no_image'); ?></div>
        <?php endif; ?>

        <div class="p-8">
            <h1 class="text-3xl font-extrabold mb-4" style="color: var(--card-heading);"><?php echo e($ad->title[app()->getLocale()] ?? $ad->title['ps'] ?? ''); ?></h1>

            <div class="flex flex-wrap items-center gap-3 text-sm mb-6" style="color: var(--card-text);">
                <span class="px-4 py-1.5 rounded-full border" style="border-color: var(--primary); color: var(--primary); background: rgba(0,210,255,0.1);"><?php echo e($ad->category); ?></span>
                <span><i class="fas fa-eye"></i> <?php echo e($ad->views); ?> <?php echo app('translator')->get('messages.views'); ?></span>
                <?php if($ad->location): ?> <span><i class="fas fa-map-marker-alt" style="color: var(--primary);"></i> <?php echo e($ad->location); ?></span> <?php endif; ?>
            </div>

            <?php if($ad->price): ?>
                <div class="text-4xl font-bold mb-6" style="color: var(--primary);">$<?php echo e($ad->price); ?></div>
            <?php endif; ?>

            <div class="text-lg leading-8 mb-8 pt-6 border-t" style="color: var(--card-text); border-color: var(--glass-border);">
                <?php echo e($ad->description[app()->getLocale()] ?? $ad->description['ps'] ?? ''); ?>

            </div>

            <div class="text-sm pt-6 border-t" style="color: var(--card-text); border-color: var(--glass-border);">
                <p><?php echo app('translator')->get('messages.published_by'); ?>: <strong style="color: var(--card-heading);"><?php echo e($ad->user->name ?? __('messages.unknown')); ?></strong></p>
            </div>

            <div class="mt-8 flex flex-wrap gap-4">
                <?php
                    $wa = \App\Models\Setting::get('social_whatsapp');
                    $ph = \App\Models\Setting::get('contact_phone');
                ?>
                <a href="https://wa.me/<?php echo e($wa ?? ''); ?>" target="_blank" class="inline-flex items-center gap-2 bg-green-500 text-white px-6 py-3 rounded-xl font-semibold hover:bg-green-600 transition">
                    <i class="fab fa-whatsapp text-xl"></i> <?php echo app('translator')->get('messages.whatsapp'); ?>
                </a>
                <a href="tel:<?php echo e($ph ?? ''); ?>" class="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-semibold transition" style="background: var(--glass-bg); border: 1px solid var(--glass-border); color: var(--body-text);">
                    <i class="fas fa-phone text-xl"></i> <?php echo app('translator')->get('messages.phone'); ?>
                </a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Web For TA\gawhar-amu-travel\resources\views/frontend/ads/show.blade.php ENDPATH**/ ?>