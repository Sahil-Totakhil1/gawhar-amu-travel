

<?php $__env->startSection('content'); ?>
<div class="max-w-5xl mx-auto">
    <h1 class="text-3xl font-bold mb-8 dark:text-white text-gray-800"><?php echo app('translator')->get('messages.settings_title'); ?></h1>

    <?php if(session('success')): ?>
        <div class="bg-green-100 dark:bg-green-800 border border-green-400 dark:border-green-600 text-green-700 dark:text-green-200 px-4 py-3 rounded mb-6">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="bg-red-100 dark:bg-red-800 border border-red-400 dark:border-red-600 text-red-700 dark:text-red-200 px-4 py-3 rounded mb-6">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('admin.settings.update')); ?>" method="POST" enctype="multipart/form-data" class="bg-white dark:bg-gray-800 shadow-md rounded-lg p-8">
        <?php echo csrf_field(); ?>

        
        <div class="mb-8 border-b dark:border-gray-700 pb-8">
            <h2 class="text-xl font-bold dark:text-white text-gray-700 mb-4"><?php echo app('translator')->get('messages.logo'); ?></h2>
            <?php if($logo): ?>
                <div class="mb-3">
                    <img src="<?php echo e(asset('storage/' . $logo)); ?>" alt="Logo" class="h-20 object-contain border dark:border-gray-600 rounded">
                </div>
            <?php endif; ?>
            <input type="file" name="logo" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2">
        </div>

        
        <div class="mb-8 border-b dark:border-gray-700 pb-8">
            <h2 class="text-xl font-bold dark:text-white text-gray-700 mb-4"><?php echo app('translator')->get('messages.background_image'); ?></h2>
            <?php if($background): ?>
                <div class="mb-3">
                    <img src="<?php echo e(asset('storage/' . $background)); ?>" alt="Background" class="h-32 object-cover border dark:border-gray-600 rounded">
                </div>
            <?php endif; ?>
            <input type="file" name="background" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2">
        </div>

        
        <div class="mb-8 border-b dark:border-gray-700 pb-8">
            <h2 class="text-xl font-bold dark:text-white text-gray-700 mb-4"><?php echo app('translator')->get('messages.company_name'); ?></h2>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                    <label class="block text-gray-600 dark:text-gray-400 mb-1"><?php echo app('translator')->get('messages.lang_ps'); ?></label>
                    <input type="text" name="company_name_ps" value="<?php echo e($companyName['ps'] ?? ''); ?>" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2">
                </div>
                <div>
                    <label class="block text-gray-600 dark:text-gray-400 mb-1"><?php echo app('translator')->get('messages.lang_dr'); ?></label>
                    <input type="text" name="company_name_dr" value="<?php echo e($companyName['dr'] ?? ''); ?>" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2">
                </div>
                <div>
                    <label class="block text-gray-600 dark:text-gray-400 mb-1"><?php echo app('translator')->get('messages.lang_en'); ?></label>
                    <input type="text" name="company_name_en" value="<?php echo e($companyName['en'] ?? ''); ?>" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2">
                </div>
            </div>
        </div>

        
        <div class="mb-8 border-b dark:border-gray-700 pb-8">
            <h2 class="text-xl font-bold dark:text-white text-gray-700 mb-4"><?php echo app('translator')->get('messages.slogan'); ?></h2>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                    <label class="block text-gray-600 dark:text-gray-400 mb-1"><?php echo app('translator')->get('messages.lang_ps'); ?></label>
                    <input type="text" name="slogan_ps" value="<?php echo e($slogan['ps'] ?? ''); ?>" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2">
                </div>
                <div>
                    <label class="block text-gray-600 dark:text-gray-400 mb-1"><?php echo app('translator')->get('messages.lang_dr'); ?></label>
                    <input type="text" name="slogan_dr" value="<?php echo e($slogan['dr'] ?? ''); ?>" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2">
                </div>
                <div>
                    <label class="block text-gray-600 dark:text-gray-400 mb-1"><?php echo app('translator')->get('messages.lang_en'); ?></label>
                    <input type="text" name="slogan_en" value="<?php echo e($slogan['en'] ?? ''); ?>" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2">
                </div>
            </div>
        </div>

        
        <div class="mb-8 border-b dark:border-gray-700 pb-8">
            <h2 class="text-xl font-bold dark:text-white text-gray-700 mb-4"><?php echo app('translator')->get('messages.about'); ?></h2>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                    <label class="block text-gray-600 dark:text-gray-400 mb-1"><?php echo app('translator')->get('messages.lang_ps'); ?></label>
                    <textarea name="about_text_ps" rows="4" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2"><?php echo e($aboutText['ps'] ?? ''); ?></textarea>
                </div>
                <div>
                    <label class="block text-gray-600 dark:text-gray-400 mb-1"><?php echo app('translator')->get('messages.lang_dr'); ?></label>
                    <textarea name="about_text_dr" rows="4" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2"><?php echo e($aboutText['dr'] ?? ''); ?></textarea>
                </div>
                <div>
                    <label class="block text-gray-600 dark:text-gray-400 mb-1"><?php echo app('translator')->get('messages.lang_en'); ?></label>
                    <textarea name="about_text_en" rows="4" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2"><?php echo e($aboutText['en'] ?? ''); ?></textarea>
                </div>
            </div>
        </div>

        
        <div class="mb-8 border-b dark:border-gray-700 pb-8">
            <h2 class="text-xl font-bold dark:text-white text-gray-700 mb-4"><?php echo app('translator')->get('messages.social_media'); ?></h2>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                    <label class="block text-gray-600 dark:text-gray-400 mb-1"><?php echo app('translator')->get('messages.facebook_link'); ?></label>
                    <input type="url" name="social_facebook" value="<?php echo e($socialFacebook); ?>" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2" placeholder="https://facebook.com/...">
                </div>
                <div>
                    <label class="block text-gray-600 dark:text-gray-400 mb-1"><?php echo app('translator')->get('messages.instagram_link'); ?></label>
                    <input type="url" name="social_instagram" value="<?php echo e($socialInstagram); ?>" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2" placeholder="https://instagram.com/...">
                </div>
                <div>
                    <label class="block text-gray-600 dark:text-gray-400 mb-1"><?php echo app('translator')->get('messages.whatsapp_number_only'); ?></label>
                    <input type="text" name="social_whatsapp" value="<?php echo e($socialWhatsapp); ?>" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2" placeholder="93700000000">
                </div>
            </div>
        </div>

        
        <div class="mb-8">
            <h2 class="text-xl font-bold dark:text-white text-gray-700 mb-4"><?php echo app('translator')->get('messages.contact_info'); ?></h2>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="block text-gray-600 dark:text-gray-400 mb-1"><?php echo app('translator')->get('messages.phone'); ?></label>
                    <input type="text" name="contact_phone" value="<?php echo e($contactPhone); ?>" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2">
                </div>
                <div>
                    <label class="block text-gray-600 dark:text-gray-400 mb-1"><?php echo app('translator')->get('messages.whatsapp'); ?></label>
                    <input type="text" name="contact_whatsapp" value="<?php echo e($contactWhatsapp); ?>" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2">
                </div>
                <div>
                    <label class="block text-gray-600 dark:text-gray-400 mb-1"><?php echo app('translator')->get('messages.email'); ?></label>
                    <input type="email" name="contact_email" value="<?php echo e($contactEmail); ?>" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2">
                </div>
                <div>
                    <label class="block text-gray-600 dark:text-gray-400 mb-1"><?php echo app('translator')->get('messages.address'); ?></label>
                    <textarea name="contact_address" rows="2" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2"><?php echo e($contactAddress); ?></textarea>
                </div>
            </div>
        </div>

        <div class="flex justify-start">
            <button type="submit" class="bg-blue-600 text-white px-8 py-2 rounded-md hover:bg-blue-700 transition"><?php echo app('translator')->get('messages.save'); ?></button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Web For TA\gawhar-amu-travel\resources\views/admin/settings/index.blade.php ENDPATH**/ ?>