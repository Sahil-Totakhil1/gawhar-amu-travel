

<?php $__env->startSection('content'); ?>
<div class="max-w-4xl mx-auto">
    <div class="bg-white dark:bg-gray-800 shadow-lg rounded-lg overflow-hidden">
        
        <?php if($ad->video_url): ?>
            <div class="relative" style="padding-top: 56.25%">
                <iframe class="absolute inset-0 w-full h-full" src="<?php echo e($ad->video_url); ?>" frameborder="0" allowfullscreen></iframe>
            </div>
        <?php elseif($ad->image): ?>
            <img src="<?php echo e(asset('storage/' . $ad->image)); ?>" alt="Ad Image" class="w-full h-64 object-cover">
        <?php else: ?>
            <div class="w-full h-64 bg-gray-200 dark:bg-gray-700 flex items-center justify-center text-gray-500 dark:text-gray-400 text-lg"><?php echo app('translator')->get('messages.no_image'); ?></div>
        <?php endif; ?>
        
        
        <div class="p-8">
            <div class="flex justify-between items-start mb-4">
                <h1 class="text-3xl font-bold text-gray-800 dark:text-white">
                    <?php echo e($ad->title[app()->getLocale()] ?? $ad->title['ps'] ?? ''); ?>

                </h1>
                <span class="px-3 py-1 text-sm rounded-full font-semibold <?php echo e($ad->status == 'active' ? 'bg-green-100 text-green-800 dark:bg-green-800 dark:text-green-200' : 'bg-red-100 text-red-800 dark:bg-red-800 dark:text-red-200'); ?>">
                    <?php echo e($ad->status == 'active' ? __('messages.active') : __('messages.inactive')); ?>

                </span>
            </div>
            
            <div class="flex items-center gap-4 text-sm text-gray-500 dark:text-gray-400 mb-6">
                <span class="bg-blue-100 dark:bg-blue-800 text-blue-700 dark:text-blue-200 px-3 py-1 rounded-full"><?php echo e($ad->category); ?></span>
                <span>👁 <?php echo e($ad->views); ?> <?php echo app('translator')->get('messages.views'); ?></span>
                <?php if($ad->location): ?>
                    <span>📍 <?php echo e($ad->location); ?></span>
                <?php endif; ?>
            </div>
            
            <?php if($ad->price): ?>
                <div class="text-2xl font-bold text-green-600 dark:text-green-400 mb-6">$<?php echo e(number_format($ad->price, 2)); ?></div>
            <?php endif; ?>
            
            <div class="prose max-w-none text-gray-700 dark:text-gray-300 mb-8">
                <p><?php echo e($ad->description[app()->getLocale()] ?? $ad->description['ps'] ?? ''); ?></p>
            </div>
            
            <div class="border-t dark:border-gray-700 pt-6 flex items-center justify-between">
                <a href="<?php echo e(route('admin.ads.edit', $ad)); ?>" class="bg-indigo-600 text-white px-6 py-2 rounded-md hover:bg-indigo-700 transition">✏️ <?php echo app('translator')->get('messages.edit'); ?></a>
                <a href="<?php echo e(route('admin.ads.index')); ?>" class="text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white">← <?php echo app('translator')->get('messages.back_to_list'); ?></a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Web For TA\gawhar-amu-travel\resources\views/admin/ads/show.blade.php ENDPATH**/ ?>