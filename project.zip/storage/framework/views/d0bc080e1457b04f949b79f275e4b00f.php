

<?php $__env->startSection('content'); ?>
<div class="py-12 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
    <h1 class="text-3xl font-bold text-gray-800 mb-6"><?php echo app('translator')->get('messages.about'); ?></h1>
    <div class="bg-white shadow-md rounded-lg p-8 text-gray-700 leading-8 text-lg">
        <?php echo e($aboutText[app()->getLocale()] ?? $aboutText['ps'] ?? __('messages.about_short')); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Web For TA\gawhar-amu-travel\resources\views/frontend/about.blade.php ENDPATH**/ ?>