<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH D:\Web For TA\gawhar-amu-travel\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php ENDPATH**/ ?>