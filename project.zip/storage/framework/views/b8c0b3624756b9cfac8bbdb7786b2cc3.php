

<?php $__env->startSection('content'); ?>
    
    <section id="home" class="relative flex flex-col items-center justify-center text-center min-h-screen py-20 px-4 hero-section" 
        <?php if($background): ?> 
            style="background-image: url('<?php echo e(asset('storage/' . $background)); ?>'); background-size: cover; background-position: center; background-repeat: no-repeat;"
        <?php else: ?> 
            style="background: radial-gradient(circle at center, #1a2639 0%, var(--body-bg) 100%);"
        <?php endif; ?>
    >
        <?php if($background): ?>
            <div class="absolute inset-0 bg-black/50"></div>
            
            
            <div class="absolute inset-0 overflow-hidden pointer-events-none mobile-particles">
                
                <div class="absolute top-0 left-0 right-0 h-1/3 flex flex-wrap justify-around items-start pt-2 md:pt-4">
                    <div class="particle particle-1"></div>
                    <div class="particle particle-2"></div>
                    <div class="particle particle-3"></div>
                    <div class="particle particle-4"></div>
                    <div class="particle particle-5"></div>
                    <div class="particle particle-6"></div>
                    <div class="particle particle-7"></div>
                    <div class="particle particle-8"></div>
                    <div class="particle particle-9"></div>
                    <div class="particle particle-10"></div>
                    <div class="particle particle-11"></div>
                    <div class="particle particle-12"></div>
                </div>

                
                <div class="absolute bottom-0 left-0 right-0 h-1/3 flex flex-wrap justify-around items-end pb-2 md:pb-4">
                    <div class="particle particle-13"></div>
                    <div class="particle particle-14"></div>
                    <div class="particle particle-15"></div>
                    <div class="particle particle-16"></div>
                    <div class="particle particle-17"></div>
                    <div class="particle particle-18"></div>
                    <div class="particle particle-19"></div>
                    <div class="particle particle-20"></div>
                    <div class="particle particle-21"></div>
                    <div class="particle particle-22"></div>
                    <div class="particle particle-23"></div>
                    <div class="particle particle-24"></div>
                </div>

                
                <div class="absolute top-1/2 left-0 right-0 -translate-y-1/2 flex justify-around opacity-30">
                    <div class="wave-particle"></div>
                    <div class="wave-particle"></div>
                    <div class="wave-particle"></div>
                    <div class="wave-particle"></div>
                    <div class="wave-particle"></div>
                    <div class="wave-particle"></div>
                    <div class="wave-particle"></div>
                    <div class="wave-particle"></div>
                </div>
            </div>
        <?php else: ?>
            <div class="absolute inset-0 overflow-hidden">
                <div class="absolute w-96 h-96 bg-gradient-to-r from-[#00d2ff] to-[#0066ff] rounded-full blur-[150px] opacity-20 animate-pulse"></div>
            </div>
        <?php endif; ?>
        <div class="relative z-10 max-w-4xl mx-auto" data-aos="fade-up">
            <h1 class="text-5xl md:text-7xl font-extrabold mb-6 leading-tight" style="color: #ffffff !important;">
                <?php echo e($companyName[app()->getLocale()] ?? $companyName['ps'] ?? __('messages.welcome')); ?>

            </h1>
            <p class="text-xl md:text-2xl mb-10 max-w-2xl mx-auto" style="color: #ffffff !important;">
                <?php echo e($slogan[app()->getLocale()] ?? $slogan['ps'] ?? __('messages.slogan')); ?>

            </p>
            <a href="#about" class="btn-primary px-10 py-4 rounded-full text-lg font-bold shadow-lg hover:scale-105 transition duration-300 scroll-link inline-block">
                <?php echo app('translator')->get('messages.more_info'); ?>
            </a>
        </div>
    </section>

    
    <section id="about" class="py-20 px-4 scroll-mt-24">
        <div class="max-w-4xl mx-auto text-center">
            <h2 class="text-4xl font-bold mb-6" style="background: linear-gradient(45deg, var(--primary), var(--secondary)); -webkit-background-clip: text; -webkit-text-fill-color: transparent;"><?php echo app('translator')->get('messages.about'); ?></h2>
            <div class="section-card text-lg leading-8">
                <?php echo e($aboutText[app()->getLocale()] ?? $aboutText['ps'] ?? __('messages.about_short')); ?>

            </div>
        </div>
    </section>

    
    <?php if($services->count() > 0): ?>
    <section id="services" class="py-20 px-4 scroll-mt-24" style="background: var(--section-alt-bg);">
        <div class="max-w-7xl mx-auto">
            <h2 class="text-4xl font-bold text-center mb-16" style="background: linear-gradient(45deg, var(--primary), var(--secondary)); -webkit-background-clip: text; -webkit-text-fill-color: transparent;"><?php echo app('translator')->get('messages.services'); ?></h2>
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="section-card text-center hover:scale-105 transition duration-300 card-3d"
                     data-aos="fade-up" data-aos-delay="<?php echo e($loop->index * 100); ?>"
                     onmousemove="tiltCard(event, this)" onmouseleave="resetTilt(this)">
                    <?php if($service->icon): ?>
                        <div class="text-5xl mb-6" style="color: var(--primary);"><i class="<?php echo e($service->icon); ?>"></i></div>
                    <?php endif; ?>
                    <h3 class="text-xl font-bold mb-3" style="color: var(--card-heading);"><?php echo e($service->title[app()->getLocale()] ?? $service->title['ps']); ?></h3>
                    <p style="color: var(--card-text);"><?php echo e($service->description[app()->getLocale()] ?? $service->description['ps'] ?? ''); ?></p>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
    <?php endif; ?>

    
    <?php if($packages->count() > 0): ?>
    <section id="packages" class="py-20 px-4 scroll-mt-24" style="background: var(--section-alt-bg);">
        <div class="max-w-7xl mx-auto">
            <h2 class="text-4xl font-bold text-center mb-16" style="background: linear-gradient(45deg, var(--primary), var(--secondary)); -webkit-background-clip: text; -webkit-text-fill-color: transparent;"><?php echo app('translator')->get('messages.packages'); ?></h2>
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
                <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="section-card overflow-hidden hover:scale-105 transition duration-300 card-3d"
                     data-aos="fade-up" data-aos-delay="<?php echo e($loop->index * 100); ?>"
                     onmousemove="tiltCard(event, this)" onmouseleave="resetTilt(this)">
                    <?php if($package->image): ?>
                        <img src="<?php echo e(asset('storage/' . $package->image)); ?>" alt="<?php echo e($package->title['ps'] ?? ''); ?>" class="w-full h-52 object-cover">
                    <?php else: ?>
                        <div class="w-full h-52 flex items-center justify-center" style="background: var(--card-bg); color: var(--card-text);"><?php echo app('translator')->get('messages.no_image'); ?></div>
                    <?php endif; ?>
                    <div class="p-6">
                        <h3 class="text-2xl font-bold mb-2" style="color: var(--card-heading);"><?php echo e($package->title[app()->getLocale()] ?? $package->title['ps']); ?></h3>
                        <div class="flex items-center text-sm mb-3" style="color: var(--card-text);">
                            <?php if($package->destination): ?> <span class="mr-4"><i class="fas fa-map-marker-alt" style="color: var(--primary);"></i> <?php echo e($package->destination); ?></span> <?php endif; ?>
                            <?php if($package->duration): ?> <span><i class="fas fa-clock" style="color: var(--primary);"></i> <?php echo e($package->duration); ?></span> <?php endif; ?>
                        </div>
                        <p class="mb-4" style="color: var(--card-text);"><?php echo e(Str::limit($package->description[app()->getLocale()] ?? $package->description['ps'] ?? '', 80)); ?></p>
                        <?php if($package->price): ?>
                            <div class="text-2xl font-bold" style="color: var(--primary);">$<?php echo e($package->price); ?></div>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
    <?php endif; ?>

    
    <?php if($destinations->count() > 0): ?>
    <section id="destinations" class="py-20 px-4 scroll-mt-24">
        <div class="max-w-7xl mx-auto">
            <h2 class="text-4xl font-bold text-center mb-16" style="background: linear-gradient(45deg, var(--primary), var(--secondary)); -webkit-background-clip: text; -webkit-text-fill-color: transparent;"><?php echo app('translator')->get('messages.our_destinations'); ?></h2>
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                <?php $__currentLoopData = $destinations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $destination): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="section-card overflow-hidden hover:scale-105 transition duration-300 card-3d"
                     data-aos="fade-up" data-aos-delay="<?php echo e($loop->index * 100); ?>"
                     onmousemove="tiltCard(event, this)" onmouseleave="resetTilt(this)">
                    <?php if($destination->image): ?>
                        <img src="<?php echo e(asset('storage/' . $destination->image)); ?>" alt="<?php echo e($destination->title['ps'] ?? ''); ?>" class="w-full h-40 object-cover">
                    <?php else: ?>
                        <div class="w-full h-40 flex items-center justify-center" style="background: var(--card-bg); color: var(--card-text);"><?php echo app('translator')->get('messages.no_image'); ?></div>
                    <?php endif; ?>
                    <div class="p-4 text-center">
                        <h3 class="text-lg font-bold" style="color: var(--card-heading);"><?php echo e($destination->title[app()->getLocale()] ?? $destination->title['ps']); ?></h3>
                        <?php if( ($destination->description[app()->getLocale()] ?? $destination->description['ps'] ?? '') ): ?>
                            <p class="text-sm mt-2" style="color: var(--card-text);"><?php echo e(Str::limit($destination->description[app()->getLocale()] ?? $destination->description['ps'], 60)); ?></p>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
    <?php endif; ?>

    
    <section id="why-us" class="py-20 px-4 scroll-mt-24" style="background: var(--section-alt-bg);">
        <div class="max-w-7xl mx-auto">
            <h2 class="text-4xl font-bold text-center mb-16" style="background: linear-gradient(45deg, var(--primary), var(--secondary)); -webkit-background-clip: text; -webkit-text-fill-color: transparent;"><?php echo app('translator')->get('messages.why_us_title'); ?></h2>
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
                <?php for($i = 1; $i <= 4; $i++): ?>
                <div class="section-card text-center hover:scale-105 transition duration-300 card-3d" data-aos="fade-up" data-aos-delay="<?php echo e(($i-1)*100); ?>"
                     onmousemove="tiltCard(event, this)" onmouseleave="resetTilt(this)">
                    <div class="text-5xl mb-6" style="color: var(--primary);">
                        <?php if($i == 1): ?> <i class="fas fa-briefcase"></i>
                        <?php elseif($i == 2): ?> <i class="fas fa-passport"></i>
                        <?php elseif($i == 3): ?> <i class="fas fa-tags"></i>
                        <?php else: ?> <i class="fas fa-shield-alt"></i>
                        <?php endif; ?>
                    </div>
                    <h3 class="text-xl font-bold mb-2" style="color: var(--card-heading);"><?php echo app('translator')->get('messages.why_us_'.$i.'_title'); ?></h3>
                    <p style="color: var(--card-text);"><?php echo app('translator')->get('messages.why_us_'.$i.'_desc'); ?></p>
                </div>
                <?php endfor; ?>
            </div>
        </div>
    </section>

    
    <?php if($testimonials->count() > 0): ?>
    <section id="testimonials" class="py-20 px-4 scroll-mt-24">
        <div class="max-w-7xl mx-auto">
            <h2 class="text-4xl font-bold text-center mb-16" style="background: linear-gradient(45deg, var(--primary), var(--secondary)); -webkit-background-clip: text; -webkit-text-fill-color: transparent;"><?php echo app('translator')->get('messages.testimonials'); ?></h2>
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
                <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="section-card text-center hover:scale-105 transition duration-300 card-3d"
                     data-aos="fade-up" data-aos-delay="<?php echo e($loop->index * 100); ?>"
                     onmousemove="tiltCard(event, this)" onmouseleave="resetTilt(this)">
                    <?php if($testimonial->image): ?>
                        <img src="<?php echo e(asset('storage/' . $testimonial->image)); ?>" alt="<?php echo e($testimonial->name); ?>" class="w-24 h-24 object-cover rounded-full mx-auto mb-6 border-4" style="border-color: var(--primary);">
                    <?php else: ?>
                        <div class="w-24 h-24 rounded-full mx-auto mb-6 border-4 flex items-center justify-center text-2xl" style="border-color: var(--primary); background: var(--card-bg); color: var(--card-text);">👤</div>
                    <?php endif; ?>
                    <div class="text-yellow-400 mb-4 text-xl">
                        <?php for($s = 1; $s <= 5; $s++): ?>
                            <?php if($s <= $testimonial->rating): ?> ★ <?php else: ?> ☆ <?php endif; ?>
                        <?php endfor; ?>
                    </div>
                    <p class="mb-4 italic" style="color: var(--card-text);">"<?php echo e($testimonial->comment); ?>"</p>
                    <h3 class="text-lg font-bold" style="color: var(--card-heading);"><?php echo e($testimonial->name); ?></h3>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
    <?php endif; ?>

    
    <?php if($teamMembers->count() > 0): ?>
    <section id="team" class="py-20 px-4 scroll-mt-24" style="background: var(--section-alt-bg);">
        <div class="max-w-7xl mx-auto">
            <h2 class="text-4xl font-bold text-center mb-16" style="background: linear-gradient(45deg, var(--primary), var(--secondary)); -webkit-background-clip: text; -webkit-text-fill-color: transparent;"><?php echo app('translator')->get('messages.our_team'); ?></h2>
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
                <?php $__currentLoopData = $teamMembers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="section-card text-center hover:scale-105 transition duration-300 card-3d"
                     data-aos="fade-up" data-aos-delay="<?php echo e($loop->index * 100); ?>"
                     onmousemove="tiltCard(event, this)" onmouseleave="resetTilt(this)">
                    <?php if($member->image): ?>
                        <img src="<?php echo e(asset('storage/' . $member->image)); ?>" alt="<?php echo e($member->name); ?>" class="w-24 h-24 object-cover rounded-full mx-auto mb-6 border-4" style="border-color: var(--primary);">
                    <?php else: ?>
                        <div class="w-24 h-24 rounded-full mx-auto mb-6 border-4 flex items-center justify-center text-2xl" style="border-color: var(--primary); background: var(--card-bg); color: var(--card-text);">👤</div>
                    <?php endif; ?>
                    <h3 class="text-lg font-bold" style="color: var(--card-heading);"><?php echo e($member->name); ?></h3>
                    <p class="text-sm mb-4" style="color: var(--card-text);"><?php echo e($member->position); ?></p>
                    <?php if($member->whatsapp_number): ?>
                        <a href="https://wa.me/<?php echo e($member->whatsapp_number); ?>" target="_blank" class="inline-flex items-center gap-1 text-sm bg-green-500 text-white px-4 py-2 rounded-full hover:bg-green-600 transition">
                            <i class="fab fa-whatsapp"></i> <?php echo app('translator')->get('messages.whatsapp'); ?>
                        </a>
                    <?php endif; ?>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
    <?php endif; ?>

    
    <?php if($ads->count() > 0): ?>
    <section id="ads" class="py-20 px-4 scroll-mt-24">
        <div class="max-w-7xl mx-auto">
            <h2 class="text-4xl font-bold text-center mb-16" style="background: linear-gradient(45deg, var(--primary), var(--secondary)); -webkit-background-clip: text; -webkit-text-fill-color: transparent;"><?php echo app('translator')->get('messages.fresh_ads'); ?></h2>
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
                <?php $__currentLoopData = $ads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="section-card overflow-hidden hover:scale-105 transition duration-300 card-3d"
                     data-aos="fade-up" data-aos-delay="<?php echo e($loop->index * 100); ?>"
                     onmousemove="tiltCard(event, this)" onmouseleave="resetTilt(this)">
                    <?php if($ad->video_url): ?>
                        <div class="relative" style="padding-top: 56.25%">
                            <iframe class="absolute inset-0 w-full h-full" src="<?php echo e($ad->video_url); ?>" frameborder="0" allowfullscreen></iframe>
                        </div>
                    <?php elseif($ad->image): ?>
                        <img src="<?php echo e(asset('storage/' . $ad->image)); ?>" alt="<?php echo e($ad->title['ps'] ?? ''); ?>" class="w-full h-52 object-cover">
                    <?php else: ?>
                        <div class="w-full h-52 flex items-center justify-center" style="background: var(--card-bg); color: var(--card-text);"><?php echo app('translator')->get('messages.no_image'); ?></div>
                    <?php endif; ?>
                    <div class="p-6">
                        <h3 class="text-2xl font-bold mb-2" style="color: var(--card-heading);"><?php echo e($ad->title[app()->getLocale()] ?? $ad->title['ps'] ?? ''); ?></h3>
                        <p class="mb-4" style="color: var(--card-text);"><?php echo e(Str::limit($ad->description[app()->getLocale()] ?? $ad->description['ps'] ?? '', 80)); ?></p>
                        <?php if($ad->price): ?>
                            <div class="text-2xl font-bold mb-4" style="color: var(--primary);">$<?php echo e($ad->price); ?></div>
                        <?php endif; ?>
                        <a href="<?php echo e(route('ads.show', $ad)); ?>" class="btn-primary px-6 py-2 rounded-full text-sm font-semibold inline-block"><?php echo app('translator')->get('messages.details'); ?></a>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="text-center mt-12">
                <a href="<?php echo e(route('ads.index')); ?>" class="inline-block px-8 py-3 rounded-full text-lg font-semibold transition" style="background: var(--glass-bg); border: 1px solid var(--glass-border); color: var(--body-text);"><?php echo app('translator')->get('messages.view_all_ads'); ?></a>
            </div>
        </div>
    </section>
    <?php endif; ?>

    
    <?php if($faqs->count() > 0): ?>
    <section id="faqs" class="py-20 px-4 scroll-mt-24" style="background: var(--section-alt-bg);">
        <div class="max-w-4xl mx-auto">
            <h2 class="text-4xl font-bold text-center mb-16" style="background: linear-gradient(45deg, var(--primary), var(--secondary)); -webkit-background-clip: text; -webkit-text-fill-color: transparent;"><?php echo app('translator')->get('messages.faq'); ?></h2>
            <div class="space-y-6">
                <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="section-card" data-aos="fade-up" data-aos-delay="<?php echo e($loop->index * 50); ?>">
                    <button class="w-full flex justify-between items-center px-6 py-4 text-right font-semibold transition rounded-xl" style="color: var(--body-text);" onclick="this.nextElementSibling.classList.toggle('hidden'); this.querySelector('i').classList.toggle('fa-chevron-down'); this.querySelector('i').classList.toggle('fa-chevron-up');">
                        <span><?php echo e($faq->question[app()->getLocale()] ?? $faq->question['ps']); ?></span>
                        <i class="fas fa-chevron-down transition" style="color: var(--primary);"></i>
                    </button>
                    <div class="hidden px-6 pb-4" style="color: var(--card-text);">
                        <?php echo e($faq->answer[app()->getLocale()] ?? $faq->answer['ps']); ?>

                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
    <?php endif; ?>

    
    <?php if($galleries->count() > 0): ?>
    <section id="galleries" class="py-20 px-4 scroll-mt-24">
        <div class="max-w-7xl mx-auto">
            <h2 class="text-4xl font-bold text-center mb-16" style="background: linear-gradient(45deg, var(--primary), var(--secondary)); -webkit-background-clip: text; -webkit-text-fill-color: transparent;"><?php echo app('translator')->get('messages.gallery'); ?></h2>
            <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
                <?php $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="relative group overflow-hidden rounded-2xl section-card" data-aos="zoom-in" data-aos-delay="<?php echo e($loop->index * 50); ?>">
                    <?php if($gallery->type == 'image'): ?>
                        <img src="<?php echo e(asset('storage/' . $gallery->url)); ?>" alt="<?php echo e($gallery->caption['ps'] ?? ''); ?>" class="w-full h-48 object-contain transition transform group-hover:scale-110">
                    <?php else: ?>
                        <a href="<?php echo e($gallery->url); ?>" target="_blank" class="block w-full h-48 flex items-center justify-center" style="background: var(--card-bg);">
                            <i class="fas fa-play-circle text-6xl hover:scale-110 transition" style="color: var(--primary);"></i>
                        </a>
                    <?php endif; ?>
                    <?php if( ($gallery->caption[app()->getLocale()] ?? $gallery->caption['ps'] ?? '') ): ?>
                    <div class="absolute bottom-0 left-0 right-0 bg-black/70 text-white text-xs px-3 py-2">
                        <?php echo e($gallery->caption[app()->getLocale()] ?? $gallery->caption['ps']); ?>

                    </div>
                    <?php endif; ?>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
    <?php endif; ?>

    
    <section id="contact" class="py-20 px-4 scroll-mt-24" style="background: var(--section-alt-bg);">
        <div class="max-w-3xl mx-auto">
            <h2 class="text-4xl font-bold text-center mb-6" style="background: linear-gradient(45deg, var(--primary), var(--secondary)); -webkit-background-clip: text; -webkit-text-fill-color: transparent;"><?php echo app('translator')->get('messages.contact'); ?></h2>
            <p class="text-center mb-12" style="color: var(--card-text);"><?php echo app('translator')->get('messages.contact_form_title'); ?></p>
            
            <?php if(session('success')): ?>
                <div class="bg-green-500/20 border border-green-500 text-green-200 px-4 py-3 rounded-xl mb-8">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <form action="<?php echo e(route('contact.submit')); ?>" method="POST" class="section-card" data-aos="fade-up">
                <?php echo csrf_field(); ?>
                <div class="mb-6">
                    <label class="block font-medium mb-2" style="color: var(--body-text);"><?php echo app('translator')->get('messages.name'); ?> *</label>
                    <input type="text" name="name" class="w-full" required>
                </div>
                <div class="mb-6">
                    <label class="block font-medium mb-2" style="color: var(--body-text);"><?php echo app('translator')->get('messages.email_optional'); ?></label>
                    <input type="email" name="email" class="w-full">
                </div>
                <div class="mb-6">
                    <label class="block font-medium mb-2" style="color: var(--body-text);"><?php echo app('translator')->get('messages.phone_optional'); ?></label>
                    <input type="text" name="phone" class="w-full">
                </div>
                <div class="mb-8">
                    <label class="block font-medium mb-2" style="color: var(--body-text);"><?php echo app('translator')->get('messages.message'); ?> *</label>
                    <textarea name="message" rows="5" class="w-full" required></textarea>
                </div>
                <button type="submit" class="btn-primary w-full py-4 rounded-xl font-bold text-lg">
                    <?php echo app('translator')->get('messages.send_message'); ?>
                </button>
            </form>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    // 3D Tilt effect for cards
    function tiltCard(event, card) {
        const rect = card.getBoundingClientRect();
        const x = event.clientX - rect.left;
        const y = event.clientY - rect.top;
        const halfWidth = rect.width / 2;
        const halfHeight = rect.height / 2;
        const angleX = -(y - halfHeight) / 10;
        const angleY = (x - halfWidth) / 10;
        card.style.transform = `perspective(1000px) rotateX(${angleX}deg) rotateY(${angleY}deg) scale(1.02)`;
    }
    function resetTilt(card) {
        card.style.transform = 'perspective(1000px) rotateX(0deg) rotateY(0deg) scale(1)';
    }
</script>

<style>
    /* ==================== د موبایل لپاره بکګراونډ عکس ==================== */
    @media (max-width: 767px) {
        .hero-section {
            background-size: contain !important;
            background-color: #0a0f1d !important;
        }
    }

    /* ==================== د متحرک څراغونو انیمیشن ==================== */
    .particle {
        width: 6px;
        height: 6px;
        border-radius: 50%;
        background: linear-gradient(135deg, #00d2ff, #0066ff);
        box-shadow: 0 0 15px rgba(0, 210, 255, 0.5);
        animation: floatParticle 4s ease-in-out infinite;
        opacity: 0;
    }

    /* د هر ذرې لپاره ځانګړی ځنډ او اندازه */
    .particle-1 { animation-delay: 0s; width: 8px; height: 8px; }
    .particle-2 { animation-delay: 0.4s; width: 5px; height: 5px; }
    .particle-3 { animation-delay: 0.8s; width: 10px; height: 10px; background: linear-gradient(135deg, #ff6b6b, #ffd93d); }
    .particle-4 { animation-delay: 1.2s; width: 6px; height: 6px; }
    .particle-5 { animation-delay: 1.6s; width: 4px; height: 4px; background: linear-gradient(135deg, #6bcb77, #00d2ff); }
    .particle-6 { animation-delay: 2s; width: 9px; height: 9px; }
    .particle-7 { animation-delay: 2.4s; width: 5px; height: 5px; background: linear-gradient(135deg, #ffd93d, #ff6b6b); }
    .particle-8 { animation-delay: 2.8s; width: 7px; height: 7px; }
    .particle-9 { animation-delay: 0.6s; width: 3px; height: 3px; background: linear-gradient(135deg, #0066ff, #00d2ff); }
    .particle-10 { animation-delay: 1s; width: 11px; height: 11px; }
    .particle-11 { animation-delay: 1.8s; width: 5px; height: 5px; background: linear-gradient(135deg, #ff6b6b, #ffd93d); }
    .particle-12 { animation-delay: 2.2s; width: 8px; height: 8px; }

    .particle-13 { animation-delay: 0.2s; width: 7px; height: 7px; }
    .particle-14 { animation-delay: 0.6s; width: 4px; height: 4px; background: linear-gradient(135deg, #6bcb77, #00d2ff); }
    .particle-15 { animation-delay: 1s; width: 10px; height: 10px; }
    .particle-16 { animation-delay: 1.4s; width: 5px; height: 5px; }
    .particle-17 { animation-delay: 1.8s; width: 8px; height: 8px; background: linear-gradient(135deg, #ffd93d, #ff6b6b); }
    .particle-18 { animation-delay: 2.2s; width: 3px; height: 3px; }
    .particle-19 { animation-delay: 2.6s; width: 9px; height: 9px; background: linear-gradient(135deg, #00d2ff, #0066ff); }
    .particle-20 { animation-delay: 0.4s; width: 6px; height: 6px; }
    .particle-21 { animation-delay: 1.2s; width: 4px; height: 4px; background: linear-gradient(135deg, #ff6b6b, #ffd93d); }
    .particle-22 { animation-delay: 1.6s; width: 11px; height: 11px; }
    .particle-23 { animation-delay: 2.4s; width: 5px; height: 5px; background: linear-gradient(135deg, #6bcb77, #00d2ff); }
    .particle-24 { animation-delay: 2.8s; width: 7px; height: 7px; }

    @keyframes floatParticle {
        0% {
            opacity: 0;
            transform: translateY(20px) scale(0.3) rotate(0deg);
        }
        25% {
            opacity: 0.8;
            transform: translateY(-10px) scale(1) rotate(90deg);
        }
        50% {
            opacity: 1;
            transform: translateY(-30px) scale(1.2) rotate(180deg);
        }
        75% {
            opacity: 0.6;
            transform: translateY(-15px) scale(0.8) rotate(270deg);
        }
        100% {
            opacity: 0;
            transform: translateY(20px) scale(0.3) rotate(360deg);
        }
    }

    /* ==================== د څپو انیمیشن ==================== */
    .wave-particle {
        width: 4px;
        height: 4px;
        border-radius: 50%;
        background: rgba(0, 210, 255, 0.4);
        animation: waveMove 5s ease-in-out infinite;
    }
    .wave-particle:nth-child(1) { animation-delay: 0s; }
    .wave-particle:nth-child(2) { animation-delay: 0.5s; }
    .wave-particle:nth-child(3) { animation-delay: 1s; }
    .wave-particle:nth-child(4) { animation-delay: 1.5s; }
    .wave-particle:nth-child(5) { animation-delay: 2s; }
    .wave-particle:nth-child(6) { animation-delay: 2.5s; }
    .wave-particle:nth-child(7) { animation-delay: 3s; }
    .wave-particle:nth-child(8) { animation-delay: 3.5s; }

    @keyframes waveMove {
        0% {
            opacity: 0.1;
            transform: translateY(0) scale(0.5);
        }
        25% {
            opacity: 0.6;
            transform: translateY(-20px) scale(1.5);
        }
        50% {
            opacity: 0.3;
            transform: translateY(0) scale(1);
        }
        75% {
            opacity: 0.7;
            transform: translateY(20px) scale(1.8);
        }
        100% {
            opacity: 0.1;
            transform: translateY(0) scale(0.5);
        }
    }

    /* ==================== د موبایل لپاره ځانګړی تنظیم ==================== */
    @media (max-width: 767px) {
        .particle {
            width: 4px !important;
            height: 4px !important;
        }
        .particle-3, .particle-7, .particle-10, .particle-15, .particle-19, .particle-22 {
            width: 6px !important;
            height: 6px !important;
        }
        .wave-particle {
            width: 3px !important;
            height: 3px !important;
        }
        .mobile-particles .absolute {
            opacity: 1;
        }
        @keyframes floatParticle {
            0% {
                opacity: 0;
                transform: translateY(15px) scale(0.5);
            }
            30% {
                opacity: 0.7;
                transform: translateY(-5px) scale(1);
            }
            60% {
                opacity: 0.9;
                transform: translateY(-20px) scale(1.1);
            }
            100% {
                opacity: 0;
                transform: translateY(15px) scale(0.5);
            }
        }
    }

    /* د کمپیوټر لپاره انیمیشن پټول (که وغواړئ) – خو دلته ساتل شوی */
    @media (min-width: 768px) {
        .mobile-particles .particle,
        .mobile-particles .wave-particle {
            opacity: 0.3;
        }
        .mobile-particles .particle:hover {
            opacity: 0.8;
        }
    }
</style>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Web For TA\gawhar-amu-travel\resources\views/frontend/home.blade.php ENDPATH**/ ?>