

<?php $__env->startSection('content'); ?>
<div class="max-w-4xl mx-auto">
    <h1 class="text-3xl font-bold mb-8 dark:text-white text-gray-800">
        <?php echo app('translator')->get('messages.edit_package_title'); ?>: <?php echo e($package->title[app()->getLocale()] ?? $package->title['ps']); ?>

    </h1>

    <?php if($errors->any()): ?>
        <div class="bg-red-100 dark:bg-red-800 border border-red-400 dark:border-red-600 text-red-700 dark:text-red-200 px-4 py-3 rounded mb-6">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('admin.packages.update', $package)); ?>" method="POST" enctype="multipart/form-data" class="bg-white dark:bg-gray-800 shadow-md rounded-lg p-8">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <!-- عنوان په دریو ژبو -->
        <div class="mb-6">
            <label class="block text-gray-700 dark:text-gray-300 font-bold mb-2"><?php echo app('translator')->get('messages.title_ps'); ?> *</label>
            <input type="text" name="title_ps" value="<?php echo e(old('title_ps', $package->title['ps'] ?? '')); ?>" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2" required>
        </div>
        <div class="mb-6">
            <label class="block text-gray-700 dark:text-gray-300 font-bold mb-2"><?php echo app('translator')->get('messages.title_dr'); ?></label>
            <input type="text" name="title_dr" value="<?php echo e(old('title_dr', $package->title['dr'] ?? '')); ?>" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2">
        </div>
        <div class="mb-6">
            <label class="block text-gray-700 dark:text-gray-300 font-bold mb-2"><?php echo app('translator')->get('messages.title_en'); ?></label>
            <input type="text" name="title_en" value="<?php echo e(old('title_en', $package->title['en'] ?? '')); ?>" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2">
        </div>

        <!-- تشریح په دریو ژبو -->
        <div class="mb-6">
            <label class="block text-gray-700 dark:text-gray-300 font-bold mb-2"><?php echo app('translator')->get('messages.description_ps'); ?></label>
            <textarea name="description_ps" rows="3" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2"><?php echo e(old('description_ps', $package->description['ps'] ?? '')); ?></textarea>
        </div>
        <div class="mb-6">
            <label class="block text-gray-700 dark:text-gray-300 font-bold mb-2"><?php echo app('translator')->get('messages.description_dr'); ?></label>
            <textarea name="description_dr" rows="3" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2"><?php echo e(old('description_dr', $package->description['dr'] ?? '')); ?></textarea>
        </div>
        <div class="mb-6">
            <label class="block text-gray-700 dark:text-gray-300 font-bold mb-2"><?php echo app('translator')->get('messages.description_en'); ?></label>
            <textarea name="description_en" rows="3" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2"><?php echo e(old('description_en', $package->description['en'] ?? '')); ?></textarea>
        </div>

        <!-- کټګوري -->
        <div class="mb-6">
            <label class="block text-gray-700 dark:text-gray-300 font-bold mb-2"><?php echo app('translator')->get('messages.category'); ?> *</label>
            <select name="category" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2" required>
                <option value=""><?php echo app('translator')->get('messages.select_option'); ?></option>
                <option value="visa" <?php echo e(old('category', $package->category) == 'visa' ? 'selected' : ''); ?>><?php echo app('translator')->get('messages.visa'); ?></option>
                <option value="tour" <?php echo e(old('category', $package->category) == 'tour' ? 'selected' : ''); ?>><?php echo app('translator')->get('messages.tour'); ?></option>
                <option value="hajj" <?php echo e(old('category', $package->category) == 'hajj' ? 'selected' : ''); ?>><?php echo app('translator')->get('messages.hajj'); ?></option>
                <option value="ticket" <?php echo e(old('category', $package->category) == 'ticket' ? 'selected' : ''); ?>><?php echo app('translator')->get('messages.ticket'); ?></option>
                <option value="residence" <?php echo e(old('category', $package->category) == 'residence' ? 'selected' : ''); ?>><?php echo app('translator')->get('messages.residence'); ?></option>
                <option value="other" <?php echo e(old('category', $package->category) == 'other' ? 'selected' : ''); ?>><?php echo app('translator')->get('messages.other'); ?></option>
            </select>
        </div>

        <!-- قیمت -->
        <div class="mb-6">
            <label class="block text-gray-700 dark:text-gray-300 font-bold mb-2"><?php echo app('translator')->get('messages.price_dollar'); ?></label>
            <input type="number" step="0.01" name="price" value="<?php echo e(old('price', $package->price)); ?>" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2">
        </div>

        <!-- منزل -->
        <div class="mb-6">
            <label class="block text-gray-700 dark:text-gray-300 font-bold mb-2"><?php echo app('translator')->get('messages.destination'); ?></label>
            <input type="text" name="destination" value="<?php echo e(old('destination', $package->destination)); ?>" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2">
        </div>

        <!-- موده -->
        <div class="mb-6">
            <label class="block text-gray-700 dark:text-gray-300 font-bold mb-2"><?php echo app('translator')->get('messages.duration'); ?></label>
            <input type="text" name="duration" value="<?php echo e(old('duration', $package->duration)); ?>" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2">
        </div>

        <!-- اوسنی انځور -->
        <?php if($package->image): ?>
        <div class="mb-6">
            <label class="block text-gray-700 dark:text-gray-300 font-bold mb-2"><?php echo app('translator')->get('messages.current_image'); ?></label>
            <img src="<?php echo e(asset('storage/' . $package->image)); ?>" alt="Package Image" class="h-20 w-20 object-cover rounded border dark:border-gray-600">
        </div>
        <?php endif; ?>

        <!-- نوی انځور -->
        <div class="mb-6">
            <label class="block text-gray-700 dark:text-gray-300 font-bold mb-2"><?php echo app('translator')->get('messages.new_image_optional'); ?></label>
            <input type="file" name="image" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2">
        </div>

        <!-- فعال/غیرفعال -->
        <div class="mb-6">
            <label class="inline-flex items-center">
                <input type="checkbox" name="is_active" value="1" <?php echo e(old('is_active', $package->is_active) ? 'checked' : ''); ?> class="rounded border-gray-300 dark:border-gray-600 text-indigo-600 shadow-sm focus:ring-indigo-500">
                <span class="mr-2 text-gray-700 dark:text-gray-300 font-bold"><?php echo app('translator')->get('messages.active'); ?></span>
            </label>
        </div>

        <!-- تڼۍ -->
        <div class="flex items-center justify-between">
            <button type="submit" class="bg-indigo-600 text-white px-6 py-2 rounded-md hover:bg-indigo-700 transition"><?php echo app('translator')->get('messages.update'); ?></button>
            <a href="<?php echo e(route('admin.packages.index')); ?>" class="text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white"><?php echo app('translator')->get('messages.back'); ?></a>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Web For TA\gawhar-amu-travel\resources\views/admin/packages/edit.blade.php ENDPATH**/ ?>