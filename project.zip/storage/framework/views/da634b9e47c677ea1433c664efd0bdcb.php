

<?php $__env->startSection('content'); ?>
<div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
    <h1 class="text-3xl font-bold text-gray-800 mb-8">FAQ سمول</h1>

    <?php if($errors->any()): ?>
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-6">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('admin.faqs.update', $faq)); ?>" method="POST" class="bg-white shadow-md rounded-lg p-8">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <!-- پوښتنه په دریو ژبو -->
        <div class="mb-6">
            <label class="block text-gray-700 font-bold mb-2">پوښتنه (پښتو) *</label>
            <input type="text" name="question_ps" value="<?php echo e(old('question_ps', $faq->question['ps'] ?? '')); ?>" class="w-full border border-gray-300 rounded-md px-4 py-2" required>
        </div>
        <div class="mb-6">
            <label class="block text-gray-700 font-bold mb-2">پوښتنه (دری)</label>
            <input type="text" name="question_dr" value="<?php echo e(old('question_dr', $faq->question['dr'] ?? '')); ?>" class="w-full border border-gray-300 rounded-md px-4 py-2">
        </div>
        <div class="mb-6">
            <label class="block text-gray-700 font-bold mb-2">Question (English)</label>
            <input type="text" name="question_en" value="<?php echo e(old('question_en', $faq->question['en'] ?? '')); ?>" class="w-full border border-gray-300 rounded-md px-4 py-2">
        </div>

        <!-- ځواب په دریو ژبو -->
        <div class="mb-6">
            <label class="block text-gray-700 font-bold mb-2">ځواب (پښتو) *</label>
            <textarea name="answer_ps" rows="4" class="w-full border border-gray-300 rounded-md px-4 py-2" required><?php echo e(old('answer_ps', $faq->answer['ps'] ?? '')); ?></textarea>
        </div>
        <div class="mb-6">
            <label class="block text-gray-700 font-bold mb-2">ځواب (دری)</label>
            <textarea name="answer_dr" rows="4" class="w-full border border-gray-300 rounded-md px-4 py-2"><?php echo e(old('answer_dr', $faq->answer['dr'] ?? '')); ?></textarea>
        </div>
        <div class="mb-6">
            <label class="block text-gray-700 font-bold mb-2">Answer (English)</label>
            <textarea name="answer_en" rows="4" class="w-full border border-gray-300 rounded-md px-4 py-2"><?php echo e(old('answer_en', $faq->answer['en'] ?? '')); ?></textarea>
        </div>

        <!-- ترتیب -->
        <div class="mb-6">
            <label class="block text-gray-700 font-bold mb-2">ترتیب (Sort Order)</label>
            <input type="number" name="sort_order" value="<?php echo e(old('sort_order', $faq->sort_order)); ?>" class="w-full border border-gray-300 rounded-md px-4 py-2">
        </div>

        <!-- فعال/غیرفعال -->
        <div class="mb-6">
            <label class="inline-flex items-center">
                <input type="checkbox" name="is_active" value="1" <?php echo e(old('is_active', $faq->is_active) ? 'checked' : ''); ?> class="rounded border-gray-300 text-indigo-600 shadow-sm focus:ring-indigo-500">
                <span class="mr-2 text-gray-700 font-bold">فعال</span>
            </label>
        </div>

        <!-- تڼۍ -->
        <div class="flex items-center justify-between">
            <button type="submit" class="bg-indigo-600 text-white px-6 py-2 rounded-md hover:bg-indigo-700 transition">تازه کول</button>
            <a href="<?php echo e(route('admin.faqs.index')); ?>" class="text-gray-600 hover:text-gray-900">بېرته</a>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Web For TA\gawhar-amu-travel\resources\views/admin/faqs/edit.blade.php ENDPATH**/ ?>