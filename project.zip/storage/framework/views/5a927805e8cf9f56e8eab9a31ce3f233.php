

<?php $__env->startSection('content'); ?>
<div class="py-12 px-4 sm:px-6 lg:px-8 max-w-3xl mx-auto">
    <h1 class="text-3xl font-bold text-gray-800 mb-8 text-center">زموږ سره اړیکه ونیسئ</h1>

    <?php if(session('success')): ?>
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-6">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-6">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('contact.submit')); ?>" method="POST" class="bg-white shadow-md rounded-lg p-8">
        <?php echo csrf_field(); ?>
        <div class="mb-4">
            <label class="block text-gray-700 font-medium mb-2">نوم *</label>
            <input type="text" name="name" value="<?php echo e(old('name')); ?>" class="w-full border border-gray-300 rounded-md px-4 py-2" required>
        </div>
        <div class="mb-4">
            <label class="block text-gray-700 font-medium mb-2">ایمیل (اختیاري)</label>
            <input type="email" name="email" value="<?php echo e(old('email')); ?>" class="w-full border border-gray-300 rounded-md px-4 py-2">
        </div>
        <div class="mb-4">
            <label class="block text-gray-700 font-medium mb-2">تلیفون (اختیاري)</label>
            <input type="text" name="phone" value="<?php echo e(old('phone')); ?>" class="w-full border border-gray-300 rounded-md px-4 py-2">
        </div>
        <div class="mb-6">
            <label class="block text-gray-700 font-medium mb-2">پیغام *</label>
            <textarea name="message" rows="5" class="w-full border border-gray-300 rounded-md px-4 py-2" required><?php echo e(old('message')); ?></textarea>
        </div>
        <button type="submit" class="bg-blue-600 text-white px-6 py-2 rounded-md hover:bg-blue-700 transition">لېږل</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Web For TA\gawhar-amu-travel\resources\views/frontend/contact.blade.php ENDPATH**/ ?>