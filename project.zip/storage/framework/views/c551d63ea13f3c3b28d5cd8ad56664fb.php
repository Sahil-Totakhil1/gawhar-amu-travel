

<?php $__env->startSection('content'); ?>
<div class="max-w-4xl mx-auto">
    <h1 class="text-3xl font-bold mb-8 dark:text-white text-gray-800">
        <?php echo app('translator')->get('messages.edit_service_title'); ?>: <?php echo e($service->title[app()->getLocale()] ?? $service->title['ps']); ?>

    </h1>

    <?php if($errors->any()): ?>
        <div class="bg-red-100 dark:bg-red-800 border border-red-400 dark:border-red-600 text-red-700 dark:text-red-200 px-4 py-3 rounded mb-6">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('admin.services.update', $service)); ?>" method="POST" class="bg-white dark:bg-gray-800 shadow-md rounded-lg p-8">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <!-- آیکون -->
        <div class="mb-6">
            <label class="block text-gray-700 dark:text-gray-300 font-bold mb-2"><?php echo app('translator')->get('messages.icon_fa'); ?></label>
            <input type="text" name="icon" value="<?php echo e(old('icon', $service->icon)); ?>" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2" placeholder="<?php echo app('translator')->get('messages.icon_fa_placeholder_edit'); ?>">
        </div>

        <!-- عنوان پښتو -->
        <div class="mb-6">
            <label class="block text-gray-700 dark:text-gray-300 font-bold mb-2"><?php echo app('translator')->get('messages.title_ps'); ?> *</label>
            <input type="text" name="title_ps" value="<?php echo e(old('title_ps', $service->title['ps'] ?? '')); ?>" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2" required>
        </div>
        <!-- عنوان دري -->
        <div class="mb-6">
            <label class="block text-gray-700 dark:text-gray-300 font-bold mb-2"><?php echo app('translator')->get('messages.title_dr'); ?></label>
            <input type="text" name="title_dr" value="<?php echo e(old('title_dr', $service->title['dr'] ?? '')); ?>" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2">
        </div>
        <!-- عنوان انګلیسي -->
        <div class="mb-6">
            <label class="block text-gray-700 dark:text-gray-300 font-bold mb-2"><?php echo app('translator')->get('messages.title_en'); ?></label>
            <input type="text" name="title_en" value="<?php echo e(old('title_en', $service->title['en'] ?? '')); ?>" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2">
        </div>

        <!-- تشریح پښتو -->
        <div class="mb-6">
            <label class="block text-gray-700 dark:text-gray-300 font-bold mb-2"><?php echo app('translator')->get('messages.description_ps'); ?></label>
            <textarea name="description_ps" rows="3" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2"><?php echo e(old('description_ps', $service->description['ps'] ?? '')); ?></textarea>
        </div>
        <!-- تشریح دري -->
        <div class="mb-6">
            <label class="block text-gray-700 dark:text-gray-300 font-bold mb-2"><?php echo app('translator')->get('messages.description_dr'); ?></label>
            <textarea name="description_dr" rows="3" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2"><?php echo e(old('description_dr', $service->description['dr'] ?? '')); ?></textarea>
        </div>
        <!-- تشریح انګلیسي -->
        <div class="mb-6">
            <label class="block text-gray-700 dark:text-gray-300 font-bold mb-2"><?php echo app('translator')->get('messages.description_en'); ?></label>
            <textarea name="description_en" rows="3" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2"><?php echo e(old('description_en', $service->description['en'] ?? '')); ?></textarea>
        </div>

        <!-- ترتیب -->
        <div class="mb-6">
            <label class="block text-gray-700 dark:text-gray-300 font-bold mb-2"><?php echo app('translator')->get('messages.sort_order'); ?></label>
            <input type="number" name="sort_order" value="<?php echo e(old('sort_order', $service->sort_order)); ?>" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2">
        </div>

        <!-- فعال/غیرفعال -->
        <div class="mb-6">
            <label class="inline-flex items-center">
                <input type="checkbox" name="is_active" value="1" <?php echo e(old('is_active', $service->is_active) ? 'checked' : ''); ?> class="rounded border-gray-300 dark:border-gray-600 text-indigo-600 shadow-sm focus:ring-indigo-500">
                <span class="mr-2 text-gray-700 dark:text-gray-300 font-bold"><?php echo app('translator')->get('messages.active'); ?></span>
            </label>
        </div>

        <!-- تڼۍ -->
        <div class="flex items-center justify-between">
            <button type="submit" class="bg-indigo-600 text-white px-6 py-2 rounded-md hover:bg-indigo-700 transition"><?php echo app('translator')->get('messages.update'); ?></button>
            <a href="<?php echo e(route('admin.services.index')); ?>" class="text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white"><?php echo app('translator')->get('messages.back'); ?></a>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Web For TA\gawhar-amu-travel\resources\views/admin/services/edit.blade.php ENDPATH**/ ?>