

<?php $__env->startSection('content'); ?>
<div class="max-w-7xl mx-auto">
    <div class="flex justify-between items-center mb-8">
        <h1 class="text-3xl font-bold dark:text-white text-gray-800"><?php echo app('translator')->get('messages.all_ads'); ?></h1>
        
        
        <?php if(auth()->user()->hasPermissionTo('ads')): ?>
            <a href="<?php echo e(route('admin.ads.create')); ?>" class="bg-blue-600 text-white px-6 py-2 rounded-md hover:bg-blue-700 transition">
                <?php echo app('translator')->get('messages.new_ad'); ?>
            </a>
        <?php endif; ?>
    </div>

    <?php if(session('success')): ?>
        <div class="bg-green-100 dark:bg-green-800 border border-green-400 dark:border-green-600 text-green-700 dark:text-green-200 px-4 py-3 rounded mb-6">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <div class="bg-white dark:bg-gray-800 shadow overflow-hidden sm:rounded-lg">
        <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
            <thead class="bg-gray-50 dark:bg-gray-700">
                <tr>
                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-300 uppercase"><?php echo app('translator')->get('messages.image'); ?></th>
                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-300 uppercase"><?php echo app('translator')->get('messages.title'); ?></th>
                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-300 uppercase"><?php echo app('translator')->get('messages.category'); ?></th>
                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-300 uppercase"><?php echo app('translator')->get('messages.price'); ?></th>
                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-300 uppercase"><?php echo app('translator')->get('messages.status'); ?></th>
                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-300 uppercase"><?php echo app('translator')->get('messages.views'); ?></th>
                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-300 uppercase"><?php echo app('translator')->get('messages.actions'); ?></th>
                </tr>
            </thead>
            <tbody class="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                <?php $__currentLoopData = $ads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="hover:bg-gray-50 dark:hover:bg-gray-700 transition">
                    <td class="px-6 py-4 whitespace-nowrap">
                        <?php if($ad->image): ?>
                            <img src="<?php echo e(asset('storage/' . $ad->image)); ?>" class="h-10 w-10 object-cover rounded">
                        <?php else: ?>
                            <span class="text-gray-400 dark:text-gray-500">--</span>
                        <?php endif; ?>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-gray-100">
                        <?php echo e($ad->title[app()->getLocale()] ?? $ad->title['ps'] ?? ''); ?>

                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400"><?php echo e($ad->category); ?></td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-gray-100">
                        <?php echo e($ad->price ? '$' . $ad->price : '--'); ?>

                    </td>
                    <td class="px-6 py-4 whitespace-nowrap">
                        <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full <?php echo e($ad->status == 'active' ? 'bg-green-100 text-green-800 dark:bg-green-800 dark:text-green-200' : 'bg-red-100 text-red-800 dark:bg-red-800 dark:text-red-200'); ?>">
                            <?php echo e($ad->status == 'active' ? __('messages.active') : __('messages.inactive')); ?>

                        </span>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400"><?php echo e($ad->views); ?></td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2 rtl:space-x-reverse">
                        
                        <?php if(auth()->user()->hasPermissionTo('ads')): ?>
                            <a href="<?php echo e(route('admin.ads.show', $ad)); ?>" class="text-blue-600 hover:text-blue-900 dark:text-blue-400 dark:hover:text-blue-300"><?php echo app('translator')->get('messages.view'); ?></a>
                        <?php endif; ?>

                        
                        <?php if(auth()->user()->hasPermissionTo('ads') && (auth()->user()->role === 'admin' || $ad->user_id === auth()->id())): ?>
                            <a href="<?php echo e(route('admin.ads.edit', $ad)); ?>" class="text-indigo-600 hover:text-indigo-900 dark:text-indigo-400 dark:hover:text-indigo-300"><?php echo app('translator')->get('messages.edit'); ?></a>
                        <?php endif; ?>

                        
                        <?php if(auth()->user()->hasPermissionTo('ads') && (auth()->user()->role === 'admin' || $ad->user_id === auth()->id())): ?>
                            <form action="<?php echo e(route('admin.ads.destroy', $ad)); ?>" method="POST" class="inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="text-red-600 hover:text-red-900 dark:text-red-400 dark:hover:text-red-300" onclick="return confirm('<?php echo app('translator')->get('messages.confirm_delete'); ?>')"><?php echo app('translator')->get('messages.delete'); ?></button>
                            </form>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <div class="mt-6">
        <?php echo e($ads->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Web For TA\gawhar-amu-travel\resources\views/admin/ads/index.blade.php ENDPATH**/ ?>