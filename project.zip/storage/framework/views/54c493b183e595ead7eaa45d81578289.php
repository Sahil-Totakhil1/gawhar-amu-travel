

<?php $__env->startSection('content'); ?>
<div class="py-12 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <h1 class="text-3xl font-bold text-center text-primary mb-12"><?php echo app('translator')->get('messages.services'); ?></h1>
    <?php if($services->count() > 0): ?>
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="bg-white rounded-xl shadow-md p-6 text-center hover:shadow-xl transition" data-aos="fade-up" data-aos-delay="<?php echo e($loop->index * 100); ?>">
                <?php if($service->icon): ?>
                    <div class="text-4xl text-blue-600 mb-4"><i class="<?php echo e($service->icon); ?>"></i></div>
                <?php endif; ?>
                <h3 class="text-xl font-semibold text-gray-800 mb-2">
                    <?php echo e($service->title[app()->getLocale()] ?? $service->title['ps']); ?>

                </h3>
                <p class="text-gray-600">
                    <?php echo e($service->description[app()->getLocale()] ?? $service->description['ps'] ?? ''); ?>

                </p>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php else: ?>
        <p class="text-center text-gray-500">تر اوسه کوم خدمت نه دی اضافه شوی.</p>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Web For TA\gawhar-amu-travel\resources\views/frontend/services.blade.php ENDPATH**/ ?>