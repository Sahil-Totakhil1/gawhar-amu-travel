<?php echo e($slot); ?>

<?php /**PATH D:\Web For TA\gawhar-amu-travel\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>