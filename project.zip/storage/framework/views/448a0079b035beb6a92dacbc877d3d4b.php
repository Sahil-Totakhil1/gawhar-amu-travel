

<?php $__env->startSection('content'); ?>
<div class="max-w-4xl mx-auto">
    <h1 class="text-3xl font-bold mb-8 dark:text-white text-gray-800">
        <?php echo app('translator')->get('messages.edit_testimonial_title'); ?>: <?php echo e($testimonial->name); ?>

    </h1>

    <?php if($errors->any()): ?>
        <div class="bg-red-100 dark:bg-red-800 border border-red-400 dark:border-red-600 text-red-700 dark:text-red-200 px-4 py-3 rounded mb-6">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('admin.testimonials.update', $testimonial)); ?>" method="POST" enctype="multipart/form-data" class="bg-white dark:bg-gray-800 shadow-md rounded-lg p-8">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <!-- نوم -->
        <div class="mb-6">
            <label class="block text-gray-700 dark:text-gray-300 font-bold mb-2"><?php echo app('translator')->get('messages.name'); ?> *</label>
            <input type="text" name="name" value="<?php echo e(old('name', $testimonial->name)); ?>" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2" required>
        </div>

        <!-- نظر -->
        <div class="mb-6">
            <label class="block text-gray-700 dark:text-gray-300 font-bold mb-2"><?php echo app('translator')->get('messages.comment_label'); ?></label>
            <textarea name="comment" rows="4" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2" required><?php echo e(old('comment', $testimonial->comment)); ?></textarea>
        </div>

        <!-- اوسنی انځور -->
        <?php if($testimonial->image): ?>
        <div class="mb-6">
            <label class="block text-gray-700 dark:text-gray-300 font-bold mb-2"><?php echo app('translator')->get('messages.current_image'); ?></label>
            <img src="<?php echo e(asset('storage/' . $testimonial->image)); ?>" alt="Current Image" class="h-20 w-20 object-cover rounded-full border dark:border-gray-600">
        </div>
        <?php endif; ?>

        <!-- نوی انځور (اختیاري) -->
        <div class="mb-6">
            <label class="block text-gray-700 dark:text-gray-300 font-bold mb-2"><?php echo app('translator')->get('messages.new_image_optional'); ?></label>
            <input type="file" name="image" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2" accept="image/*">
        </div>

        <!-- ستوري -->
        <div class="mb-6">
            <label class="block text-gray-700 dark:text-gray-300 font-bold mb-2"><?php echo app('translator')->get('messages.rating_label'); ?></label>
            <select name="rating" class="w-full border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md px-4 py-2" required>
                <option value="5" <?php echo e(old('rating', $testimonial->rating) == '5' ? 'selected' : ''); ?>><?php echo app('translator')->get('messages.rating_5'); ?></option>
                <option value="4" <?php echo e(old('rating', $testimonial->rating) == '4' ? 'selected' : ''); ?>><?php echo app('translator')->get('messages.rating_4'); ?></option>
                <option value="3" <?php echo e(old('rating', $testimonial->rating) == '3' ? 'selected' : ''); ?>><?php echo app('translator')->get('messages.rating_3'); ?></option>
                <option value="2" <?php echo e(old('rating', $testimonial->rating) == '2' ? 'selected' : ''); ?>><?php echo app('translator')->get('messages.rating_2'); ?></option>
                <option value="1" <?php echo e(old('rating', $testimonial->rating) == '1' ? 'selected' : ''); ?>><?php echo app('translator')->get('messages.rating_1'); ?></option>
            </select>
        </div>

        <!-- فعال/غیرفعال -->
        <div class="mb-6">
            <label class="inline-flex items-center">
                <input type="checkbox" name="is_active" value="1" <?php echo e(old('is_active', $testimonial->is_active) ? 'checked' : ''); ?> class="rounded border-gray-300 dark:border-gray-600 text-indigo-600 shadow-sm focus:ring-indigo-500">
                <span class="mr-2 text-gray-700 dark:text-gray-300 font-bold"><?php echo app('translator')->get('messages.active'); ?></span>
            </label>
        </div>

        <!-- تڼۍ -->
        <div class="flex items-center justify-between">
            <button type="submit" class="bg-indigo-600 text-white px-6 py-2 rounded-md hover:bg-indigo-700 transition"><?php echo app('translator')->get('messages.update'); ?></button>
            <a href="<?php echo e(route('admin.testimonials.index')); ?>" class="text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white"><?php echo app('translator')->get('messages.back'); ?></a>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Web For TA\gawhar-amu-travel\resources\views/admin/testimonials/edit.blade.php ENDPATH**/ ?>