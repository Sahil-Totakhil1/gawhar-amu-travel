<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('testimonials', function (Blueprint $table) {
            $table->id();
            $table->string('name');                 // د نظر ورکوونکي نوم
            $table->text('comment');                // د نظر متن
            $table->string('image')->nullable();    // د نظر ورکوونکي انځور (اختیاري)
            $table->tinyInteger('rating')->default(5); // له ۱ تر ۵ پورې ستوري
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('testimonials');
    }
};